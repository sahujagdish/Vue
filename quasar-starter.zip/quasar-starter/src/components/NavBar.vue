<template>
  <q-header elevated>
    <q-toolbar>
      <q-toolbar-title>My App</q-toolbar-title>
      <q-btn-dropdown label="Menu" color="primary" flat>
        <q-list>
          <template v-for="parent in menuItems" :key="parent.label">
            <q-expansion-item :label="parent.label" :icon="parent.icon" expand-separator>
              <q-item clickable v-ripple @click="navigate(parent.route)">
                <q-item-section>{{ parent.label }} Main</q-item-section>
              </q-item>
              <q-item v-for="child in parent.children" :key="child.label" clickable v-ripple @click="navigate(child.route)">
                <q-item-section avatar>
                  <q-icon :name="child.icon" />
                </q-item-section>
                <q-item-section>{{ child.label }}</q-item-section>
              </q-item>
            </q-expansion-item>
          </template>
        </q-list>
      </q-btn-dropdown>
      <q-tabs v-model="activeTab" dense class="text-primary" active-color="primary" indicator-color="primary">
        <q-route-tab v-for="tab in tabs" :key="tab.name" :to="tab.route" :label="tab.label" :icon="tab.icon" />
      </q-tabs>
    </q-toolbar>
  </q-header>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
const router = useRouter()
const activeTab = ref('home')
const menuItems = [
  { label: 'Dashboard', icon: 'dashboard', route: '/dashboard', children: [
    { label: 'Reports', icon: 'bar_chart', route: '/dashboard/reports' },
    { label: 'Analytics', icon: 'analytics', route: '/dashboard/analytics' }
  ]},
  { label: 'Settings', icon: 'settings', route: '/settings', children: [
    { label: 'Profile', icon: 'person', route: '/settings/profile' },
    { label: 'Security', icon: 'lock', route: '/settings/security' }
  ]}
]
const tabs = [
  { name: 'home', label: 'Home', icon: 'home', route: '/' },
  { name: 'about', label: 'About', icon: 'info', route: '/about' },
  { name: 'contact', label: 'Contact', icon: 'mail', route: '/contact' }
]
function navigate(route) { router.push(route) }
</script>
