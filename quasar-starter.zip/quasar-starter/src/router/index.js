import { createRouter, createWebHistory } from 'vue-router'
import HomePage from '../pages/HomePage.vue'
import AboutPage from '../pages/AboutPage.vue'
import ContactPage from '../pages/ContactPage.vue'

const routes = [
  { path: '/', component: HomePage },
  { path: '/about', component: AboutPage },
  { path: '/contact', component: ContactPage },
  { path: '/dashboard', component: () => import('../pages/Dashboard.vue') },
  { path: '/dashboard/reports', component: () => import('../pages/Reports.vue') },
  { path: '/dashboard/analytics', component: () => import('../pages/Analytics.vue') },
  { path: '/settings', component: () => import('../pages/Settings.vue') },
  { path: '/settings/profile', component: () => import('../pages/Profile.vue') },
  { path: '/settings/security', component: () => import('../pages/Security.vue') }
]

export default createRouter({
  history: createWebHistory(),
  routes
})