module.exports = function (ctx) {
  return {
    supportTS: false,
    css: ['app.scss'],
    build: {
      vueRouterMode: 'history'
    },
    framework: {
      config: {},
      plugins: []
    }
  }
}