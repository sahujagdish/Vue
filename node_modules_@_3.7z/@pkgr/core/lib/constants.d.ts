/// <reference types="node" preserve="true" />
export declare const CWD: string;
export interface CjsRequire extends NodeJS.Require {
    <T>(id: string): T;
}
export declare const cjsRequire: CjsRequire;
export declare const EVAL_FILENAMES: Set<string>;
export declare const EXTENSIONS: string[];
