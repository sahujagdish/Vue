// This file contains the types for app-vite/bex/background.js
// It is mapped through package.json > exports

export { createBridge } from "./create-bridge";
