<template>
  <q-page padding>
    <!-- content -->
  </q-page>
</template>

<script setup lang="ts">
//
</script>
