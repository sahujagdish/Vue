<template>
  <div>My component</div>
</template>

<script setup lang="ts">
//
</script>
