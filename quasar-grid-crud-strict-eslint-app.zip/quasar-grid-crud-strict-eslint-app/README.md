# Quasar Grid CRUD App (Strict Mode + ESLint + Prettier)

This project demonstrates a Quasar + Vue 3 + TypeScript + Pinia application with:
- QTable for server-side pagination, sorting
- CRUD operations using mock data in Pinia store
- Row selection with select/selectAll checkboxes
- TypeScript strict mode enabled
- ESLint + Prettier for strict linting and formatting

## Features
- Axios ready (mock data used for now)
- Pinia for state management
- GitHub-ready structure

## How to Run
```bash
npm install
quasar dev
```

## Linting
```bash
npm run lint
npm run lint:fix
```
