<template>
  <q-page padding>
    <GridTable />
  </q-page>
</template>
<script setup lang="ts">
import GridTable from './components/GridTable.vue';
</script>
