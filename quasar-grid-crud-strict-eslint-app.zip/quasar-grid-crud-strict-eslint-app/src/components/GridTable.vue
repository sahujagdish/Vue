<template>
  <div>
    <q-input v-model="newName" label="New Item" />
    <q-btn label="Add" @click="addNew" />
    <q-table
      :rows="pagedRows"
      :columns="columns"
      row-key="id"
      selection="multiple"
      v-model:selected="gridStore.selected"
      :pagination.sync="gridStore.pagination"
      :loading="loading"
      @request="onRequest"
    >
      <template v-slot:top-right>
        <q-btn label="Select All" @click="gridStore.selectAll" />
        <q-btn label="Clear" @click="gridStore.clearSelection" />
      </template>
      <template v-slot:body-cell-actions="props">
        <q-btn flat icon="edit" @click="editRow(props.row)" />
        <q-btn flat icon="delete" @click="deleteRow(props.row)" />
      </template>
    </q-table>
  </div>
</template>
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { useGridStore, Item } from '../stores/grid';

const gridStore = useGridStore();
const loading = ref(false);
const newName = ref<string>('');

interface Column {
  name: string;
  label: string;
  field: string;
  sortable?: boolean;
}

const columns: Column[] = [
  { name: 'name', label: 'Name', field: 'name', sortable: true },
  { name: 'actions', label: 'Actions', field: 'actions' }
];

onMounted(() => {
  gridStore.initMockData();
});

const pagedRows = computed<Item[]>(() => gridStore.fetchData());

function onRequest(props: any): void {
  gridStore.pagination = props.pagination;
  gridStore.sortBy = props.sortBy;
  gridStore.descending = props.descending;
}

function addNew(): void {
  if (newName.value.trim()) {
    gridStore.addItem(newName.value.trim());
    newName.value = '';
  }
}

function editRow(row: Item): void {
  const updated = prompt('Edit name:', row.name);
  if (updated) gridStore.updateItem(row.id, updated);
}

function deleteRow(row: Item): void {
  if (confirm('Delete this item?')) gridStore.deleteItem(row.id);
}
</script>
