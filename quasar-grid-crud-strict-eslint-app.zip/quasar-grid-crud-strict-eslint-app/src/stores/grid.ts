import { defineStore } from 'pinia';

export interface Item {
  id: number;
  name: string;
}

export const useGridStore = defineStore('grid', {
  state: () => ({
    rows: [] as Item[],
    pagination: { page: 1, rowsPerPage: 5, rowsNumber: 0 },
    sortBy: 'name' as keyof Item,
    descending: false,
    selected: [] as Item[],
    nextId: 6
  }),
  actions: {
    initMockData(): void {
      this.rows = [
        { id: 1, name: 'Alpha' },
        { id: 2, name: 'Bravo' },
        { id: 3, name: 'Charlie' },
        { id: 4, name: 'Delta' },
        { id: 5, name: 'Echo' }
      ];
      this.pagination.rowsNumber = this.rows.length;
    },
    fetchData(): Item[] {
      let data = [...this.rows];
      if (this.sortBy) {
        data.sort((a, b) => {
          const res = a[this.sortBy].localeCompare(b[this.sortBy]);
          return this.descending ? -res : res;
        });
      }
      const start = (this.pagination.page - 1) * this.pagination.rowsPerPage;
      const end = start + this.pagination.rowsPerPage;
      return data.slice(start, end);
    },
    addItem(name: string): void {
      this.rows.push({ id: this.nextId++, name });
      this.pagination.rowsNumber = this.rows.length;
    },
    updateItem(id: number, name: string): void {
      const item = this.rows.find(r => r.id === id);
      if (item) item.name = name;
    },
    deleteItem(id: number): void {
      this.rows = this.rows.filter(r => r.id !== id);
      this.pagination.rowsNumber = this.rows.length;
    },
    selectAll(): void {
      this.selected = [...this.rows];
    },
    clearSelection(): void {
      this.selected = [];
    }
  }
});
