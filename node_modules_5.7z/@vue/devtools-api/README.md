# @vue/devtools-api

> Plugins API for easier DevTools integrations.

## Getting Started

Please follow the documentation at [devtools.vuejs.org](https://devtools.vuejs.org/plugins/api).
