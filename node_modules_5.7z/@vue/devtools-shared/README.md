# @vue/devtools-shared

> Internal utility types shared across @vue/devtools packages.
