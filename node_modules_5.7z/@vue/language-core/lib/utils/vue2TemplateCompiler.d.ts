import * as CompilerDOM from '@vue/compiler-dom';
export declare const compile: typeof CompilerDOM.compile;
