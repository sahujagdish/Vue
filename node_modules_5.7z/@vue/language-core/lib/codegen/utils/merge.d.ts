import type { Code } from '../../types';
export declare function generateIntersectMerge(codes: Code[]): Generator<Code>;
export declare function generateSpreadMerge(codes: Code[]): Generator<Code>;
