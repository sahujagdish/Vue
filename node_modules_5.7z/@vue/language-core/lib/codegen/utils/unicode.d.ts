import type { Code, VueCodeInformation } from '../../types';
export declare function generateUnicode(code: string, offset: number, info: VueCodeInformation): Generator<Code>;
