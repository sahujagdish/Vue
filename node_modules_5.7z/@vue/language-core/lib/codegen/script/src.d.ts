import type { Code, SfcBlockAttr } from '../../types';
export declare function generateSrc(src: SfcBlockAttr): Generator<Code>;
