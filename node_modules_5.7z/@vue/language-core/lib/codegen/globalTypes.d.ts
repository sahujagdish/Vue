import type { VueCompilerOptions } from '../types';
export declare function getGlobalTypesFileName(options: VueCompilerOptions): string;
export declare function generateGlobalTypes(options: VueCompilerOptions): string;
