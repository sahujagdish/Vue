import type { Code, Sfc } from '../../types';
export declare function generateStyleImports(style: Sfc['styles'][number]): Generator<Code>;
