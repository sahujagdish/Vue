import type { Code } from '../../types';
import type { ScriptCodegenOptions } from '../script';
export declare function generateStyleModules(options: ScriptCodegenOptions): Generator<Code>;
