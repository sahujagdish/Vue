import type { CodeInformation } from '@volar/language-core';
export declare const allCodeFeatures: CodeInformation;
