import { type VueLanguagePlugin } from './types';
export * from './plugins/shared';
export declare function createPlugins(pluginContext: Parameters<VueLanguagePlugin>[0]): import("./types").VueLanguagePluginReturn[];
