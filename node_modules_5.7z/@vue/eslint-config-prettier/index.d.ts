declare const _exports: import("eslint").Linter.Config;
export = _exports;
