# @vue/devtools-kit

> Utility kit for DevTools.
