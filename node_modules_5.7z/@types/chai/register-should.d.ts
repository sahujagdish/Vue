declare global {
    interface Object {
        should: Chai.Assertion;
    }
}

export {};
