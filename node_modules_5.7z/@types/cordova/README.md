# Installation
> `npm install --save @types/cordova`

# Summary
This package contains type definitions for cordova (http://cordova.apache.org).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cordova.

### Additional Details
 * Last updated: Mon, 06 Nov 2023 22:41:05 GMT
 * Dependencies: none

# Credits
These definitions were written by [Microsoft Open Technologies Inc](http://msopentech.com).
