# Installation
> `npm install --save @types/filesystem`

# Summary
This package contains type definitions for filesystem (http://www.w3.org/TR/file-system-api/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/filesystem.

### Additional Details
 * Last updated: Thu, 21 Mar 2024 19:06:57 GMT
 * Dependencies: [@types/filewriter](https://npmjs.com/package/@types/filewriter)

# Credits
These definitions were written by [Kon](http://phyzkit.net/).
