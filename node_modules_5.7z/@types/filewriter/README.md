# Installation
> `npm install --save @types/filewriter`

# Summary
This package contains type definitions for filewriter (http://www.w3.org/TR/file-writer-api/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/filewriter.

### Additional Details
 * Last updated: Tue, 30 Jan 2024 21:35:45 GMT
 * Dependencies: none

# Credits
These definitions were written by [Kon](http://phyzkit.net/).
