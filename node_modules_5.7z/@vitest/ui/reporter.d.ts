import type { Reporter } from 'vitest'

declare const reporter: Reporter
export default reporter
