export declare function binarySearch(values: number[], searchValue: number): {
    low: number;
    high: number;
    match: number | undefined;
};
