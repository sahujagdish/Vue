export declare function translateOffset(start: number, fromOffsets: number[], toOffsets: number[], fromLengths: number[], toLengths?: number[]): number | undefined;
