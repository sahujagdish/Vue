export declare function resolveFileLanguageId(path: string): string | undefined;
