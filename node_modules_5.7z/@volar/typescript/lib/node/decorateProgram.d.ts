import type { Language } from '@volar/language-core';
import type * as ts from 'typescript';
export declare function decorateProgram(language: Language<string>, program: ts.Program): void;
