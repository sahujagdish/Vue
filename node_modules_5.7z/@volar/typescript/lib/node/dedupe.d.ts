import type * as ts from 'typescript';
export declare function dedupeDocumentSpans<T extends ts.DocumentSpan>(items: T[]): T[];
