/* eslint-disable */
/// <reference types="@quasar/app-vite" />

/// <reference types="vite/client" />
