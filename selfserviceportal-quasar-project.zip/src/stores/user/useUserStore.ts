// import { defineStore } from 'pinia'
// //import type { GridRow } from '../../services/user/types'
// import type { GridRow } from 'src/types/components'
// import {
//   fetchUsers,
//   addUser,
//   updateUser,
//   deleteUser,
//   bulkDelete
// } from '../../services/user'
// import type { AxiosError } from 'axios'

// export const useUserStore = defineStore('user', {
//   state: () => {
//     return {
//       users: [] as GridRow[],
//       loading: false
//     }
//   },

//   getters: {
//     getUserById: (state) => {
//       return (id: string | number): GridRow | undefined =>
//         state.users.find((u) => u.id === id)
//     }
//   },

//   actions: {
//     initUsers(data: GridRow[]): void {
//       this.users = data
//     },

//     addUser(user: GridRow): void {
//       this.users.push(user)
//     },

//     updateUser(user: GridRow): void {
//       const idx = this.users.findIndex((u) => u.id === user.id)
//       if (idx !== -1) {
//         this.users[idx] = user
//       }
//     },

//     removeUser(id: string | number): void {
//       const idx = this.users.findIndex((u) => u.id === id)
//       if (idx !== -1) {
//         this.users.splice(idx, 1)
//       }
//     },

//     bulkRemove(ids: (string | number)[]): void {
//       this.users = this.users.filter((u) => !ids.includes(u.id))
//     },

//     async dispatchFetchUsers(): Promise<{ status?: number }> {
//       try {
//         this.loading = true
//         const data = await fetchUsers()
//         debugger;
//         this.loading = false
//         this.initUsers(data)
//         return { status: 200 }
//       } catch (error) {
//         const _error = error as AxiosError<string>
//         const status = _error.response?.status
//         return status !== undefined ? { status } : {}
//       }
//     },

//     async dispatchAddUser(newUser: GridRow): Promise<{ status?: number }> {
//       try {
//         const data = await addUser(newUser)
//         this.addUser(data)
//         return { status: 201 }
//       } catch (error) {
//         const _error = error as AxiosError<string>
//         const status = _error.response?.status
//         return status !== undefined ? { status } : {}
//       }
//     },

//     async dispatchUpdateUser(updatedUser: GridRow): Promise<{ status?: number }> {
//       try {
//         const data = await updateUser(updatedUser)
//         this.updateUser(data)
//         return { status: 200 }
//       } catch (error) {
//         const _error = error as AxiosError<string>
//         const status = _error.response?.status
//         return status !== undefined ? { status } : {}
//       }
//     },

//     async dispatchDeleteUser(id: string | number): Promise<{ status?: number }> {
//       try {
//         await deleteUser(id)
//         this.removeUser(id)
//         return { status: 200 }
//       } catch (error) {
//         const _error = error as AxiosError<string>
//         const status = _error.response?.status
//         return status !== undefined ? { status } : {}
//       }
//     },

//     async dispatchBulkDelete(ids: (string | number)[]): Promise<{ status?: number }> {
//       try {
//         await bulkDelete(ids)
//         this.bulkRemove(ids)
//         return { status: 200 }
//       } catch (error) {
//         const _error = error as AxiosError<string>
//         const status = _error.response?.status
//         return status !== undefined ? { status } : {}
//       }
//     }
//   }
// })
