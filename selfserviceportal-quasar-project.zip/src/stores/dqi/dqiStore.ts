import { defineStore } from 'pinia'
import type { AxiosError } from 'axios'
import { API } from '../../services'
import type { DqiReportDTO, DqiParams } from '../../services/dqi/types'

// const defaultParams: DqiParams = {
//     reportView: 'Consolidated',
//     cycle: 'Jun 2025',
//     portfolio: 'Retail',
//     fileName: 'DQI_Report_1.csv'
// }

const defaultResponse: DqiReportDTO = {
    nameWeighted: '95%',
    nameActual: '92%',
    dobWeighted: '90%',
    dobActual: '88%',
    panWeighted: '85%',
    panActual: '80%',
    pincodeWeighted: '91%',
    pincodeActual: '89%',
    phoneWeighted: '88%',
    phoneActual: '84%',
    dpdWeighted: '86%',
    dpdActual: '82%',
    sanctionWeighted: '87%',
    sanctionActual: '83%',
    openedWeighted: '89%',
    openedActual: '85%',
    balanceWeighted: '90%',
    balanceActual: '86%',
    accountTypeWeighted: '92%',
    accountTypeActual: '88%',
    score: '89.7%'
}

export const useDqiStore = defineStore('dqi', {
    state: () => ({
        report: {
            nameWeighted: '',
            nameActual: '',
            dobWeighted: '',
            dobActual: '',
            panWeighted: '',
            panActual: '',
            pincodeWeighted: '',
            pincodeActual: '',
            phoneWeighted: '',
            phoneActual: '',
            dpdWeighted: '',
            dpdActual: '',
            sanctionWeighted: '',
            sanctionActual: '',
            openedWeighted: '',
            openedActual: '',
            balanceWeighted: '',
            balanceActual: '',
            accountTypeWeighted: '',
            accountTypeActual: '',
            score: ''
        } as DqiReportDTO
    }),

    getters: {
        getScore: (state) => state.report.score,
        getFieldWeighted: (state) => {
            return (field: keyof DqiReportDTO) => state.report[field]
        }
    },

    actions: {
        initReport(data: DqiReportDTO) {
            this.report = data
        },

        async dispatchGetReport(params: DqiParams): Promise<{ status: number | undefined }> {
            try {
                const { status, data } = await API.dqi.getReport(params)

                if (status === 200) {
                    this.initReport(data)
                }

                return { status }
            } catch (error) {
                const _error = error as AxiosError<string>
                return { status: _error.response?.status }
            }
        },

        dispatchDefaultReport() {
            this.initReport(defaultResponse)
        }
    }
})
