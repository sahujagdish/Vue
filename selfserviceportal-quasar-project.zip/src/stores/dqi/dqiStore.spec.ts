import { setActivePinia, createPinia } from 'pinia'
import { useDqiStore } from './dqiStore'
import { API } from '../../services'
import type { DqiParams, DqiReportDTO } from '../../services/dqi/types'
import { AxiosHeaders } from 'axios'
import type { AxiosResponse } from 'axios'
import { describe, it, expect, beforeEach, vi } from 'vitest'

vi.mock('@/services', () => ({
    API: {
        dqi: {
            getReport: vi.fn()
        }
    }
}))

describe('dqiStore', () => {
    let store: ReturnType<typeof useDqiStore>

    const mockParams: DqiParams = {
        reportView: 'Consolidated',
        cycle: 'Jun 2025',
        portfolio: 'Retail',
        fileName: 'DQI_Report_1.csv'
    }

    const mockResponse: DqiReportDTO = {
        nameWeighted: '95%',
        nameActual: '92%',
        dobWeighted: '90%',
        dobActual: '88%',
        panWeighted: '85%',
        panActual: '80%',
        pincodeWeighted: '91%',
        pincodeActual: '89%',
        phoneWeighted: '88%',
        phoneActual: '84%',
        dpdWeighted: '86%',
        dpdActual: '82%',
        sanctionWeighted: '87%',
        sanctionActual: '83%',
        openedWeighted: '89%',
        openedActual: '85%',
        balanceWeighted: '90%',
        balanceActual: '86%',
        accountTypeWeighted: '92%',
        accountTypeActual: '88%',
        score: '89.7%'
    }

    const mockAxiosResponse: AxiosResponse<DqiReportDTO> = {
        data: mockResponse,
        status: 200,
        statusText: 'OK',
        headers: {},
        config: {
            headers: new AxiosHeaders(),
            method: 'get',
            url: '/api/dqi-report',
            timeout: 0,
            withCredentials: false,
            transitional: {},
            xsrfCookieName: '',
            xsrfHeaderName: '',
            maxContentLength: -1,
            maxBodyLength: -1,
            env: {},
            transformRequest: [],
            transformResponse: [],
            paramsSerializer: () => ''
        },
        request: {}
    }

    beforeEach(() => {
        setActivePinia(createPinia())
        store = useDqiStore()
        vi.clearAllMocks()
    })

    it('initializes with empty report', () => {
        expect(store.report.score).toBe('')
        expect(store.getScore).toBe('')
    })

    it('fetches and sets report data successfully', async () => {
        vi.mocked(API.dqi.getReport).mockResolvedValue(mockAxiosResponse)

        const result = await store.dispatchGetReport(mockParams)

        expect(API.dqi.getReport).toHaveBeenCalledWith(mockParams)
        expect(result.status).toBe(200)
        expect(store.report.score).toBe('89.7%')
        expect(store.getFieldWeighted('dobActual')).toBe('88%')
    })

    it('handles API error gracefully', async () => {
        vi.mocked(API.dqi.getReport).mockRejectedValue({
            response: { status: 500 }
        })

        const result = await store.dispatchGetReport(mockParams)

        expect(result.status).toBe(500)
        expect(store.report.score).toBe('')
    })
})
