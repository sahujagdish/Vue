import { defineStore } from 'pinia'
import { ref, watch } from 'vue'
import { authenticate } from 'src/services/login'
import type { LoginPayload } from 'src/services/login/types'

export const useLoginStore = defineStore('login', () => {
    const isAuthenticated = ref(false)
    const user = ref<null | { username: string; role: string }>(null)
    const error = ref('')

    // Restore from sessionStorage
    const storedUser = sessionStorage.getItem('user')
    const storedAuth = sessionStorage.getItem('isAuthenticated')
    if (storedUser) user.value = JSON.parse(storedUser)
    if (storedAuth === 'true') isAuthenticated.value = true

    // Watch and persist changes
    watch(user, val => {
        if (val) {
            sessionStorage.setItem('user', JSON.stringify(val))
        } else {
            sessionStorage.removeItem('user')
        }
    }, { deep: true })

    watch(isAuthenticated, val => {
        sessionStorage.setItem('isAuthenticated', val.toString())
    })

    async function login(payload: LoginPayload) {
        const result = await authenticate(payload)
        if (result.success) {
            isAuthenticated.value = true
            user.value = result.user!
            error.value = ''
            return true
        } else {
            error.value = result.message || 'Invalid credentials'
            return false
        }
    }

    function logout() {
        isAuthenticated.value = false
        user.value = null
        sessionStorage.clear()
    }

    return {
        isAuthenticated,
        user,
        error,
        login,
        logout
    }
})
