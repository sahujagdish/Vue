// src/stores/tickets/grid.ts
import { defineStore } from 'pinia'

export interface Item {
  id: number
  name: string
}

function compareValues(a: unknown, b: unknown): number {
  if (typeof a === 'number' && typeof b === 'number') {
    return a - b
  }
  if (typeof a === 'string' && typeof b === 'string') {
    return a.localeCompare(b, undefined, { sensitivity: 'base' })
  }
  return 0
}

export const useGridStore = defineStore('grid', {
  state: () => ({
    rows: [] as Item[],
    pagination: { page: 1, rowsPerPage: 5, rowsNumber: 0 },
    sortBy: 'name' as keyof Item,
    descending: false,
    selected: [] as Item[],
    nextId: 6
  }),
  actions: {
    initMockData: () => {
      const store = useGridStore()
      store.rows = [
        { id: 1, name: 'Alpha' },
        { id: 2, name: 'Bravo' },
        { id: 3, name: 'Charlie' },
        { id: 4, name: 'Delta' },
        { id: 5, name: 'Echo' },
        { id: 6, name: 'Alpha' },
        { id: 7, name: 'Bravo' },
        { id: 8, name: 'Charlie' },
        { id: 9, name: 'Delta' },
        { id: 10, name: 'Echo' },
        { id: 11, name: 'Alpha' },
        { id: 12, name: 'Bravo6' },
        { id: 13, name: 'Charlie5' },
        { id: 14, name: 'Delta5' },
        { id: 15, name: 'Echo4' },
        { id: 16, name: 'Alpha4' },
        { id: 17, name: 'Bravo3' },
        { id: 18, name: 'Charli3e' },
        { id: 19, name: 'Delta2' },
        { id: 20, name: 'Echo1' },
      ]
      store.pagination.rowsNumber = store.rows.length
    },

    fetchData: (
      page = 1,
      rowsPerPage = 5,
      sortBy: keyof Item = 'name',
      descending = false
    ): Item[] => {
      const store = useGridStore()
      const data = [...store.rows]

      if (sortBy) {
        data.sort((ra, rb) => {
          const a = ra[sortBy]
          const b = rb[sortBy]
          const base = compareValues(a, b)
          return descending ? -base : base
        })
      }

      const start = (page - 1) * rowsPerPage
      const end = start + rowsPerPage
      return data.slice(start, end)
    },

    addItem: (name: string): void => {
      const store = useGridStore()
      store.rows.push({ id: store.nextId++, name })
      store.pagination.rowsNumber = store.rows.length
    },

    updateItem: (id: number, name: string): void => {
      const store = useGridStore()
      const item = store.rows.find(r => r.id === id)
      if (item) item.name = name
    },

    deleteItem: (id: number): void => {
      const store = useGridStore()
      store.rows = store.rows.filter(r => r.id !== id)
      store.pagination.rowsNumber = store.rows.length
    },

    selectAll: (): void => {
      const store = useGridStore()
      store.selected = [...store.rows]
    },

    clearSelection: (): void => {
      const store = useGridStore()
      store.selected = []
    }
  }
})
