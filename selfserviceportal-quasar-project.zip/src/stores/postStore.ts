import { acceptHMRUpdate, defineStore } from 'pinia'
import type { Post } from 'src/types'

export const usePostStore = defineStore('post', {
  state: () => ({
    posts: [] as Post[]
  }),
  actions: {
    async fetchPosts(): Promise<void> {
      const res = await fetch('https://jsonplaceholder.typicode.com/posts')
      const data: Post[] = await res.json()
      this.posts = data
    },
    addPost(post: Post): void {
      this.posts.push(post)
    },
    deletePost(id: number): void {
      this.posts = this.posts.filter(p => p.id !== id)
    }
  }
})


if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(usePostStore, import.meta.hot));
}
