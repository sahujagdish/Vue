import { acceptHMRUpdate, defineStore } from 'pinia'
import type { FormData } from 'src/types'

export const useHomeStore = defineStore('home', {
  state: () => ({
    formData: {} as FormData
  }),
  actions: {
    submitForm(data: FormData) {
      this.formData = data
    }
  }
})


if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useHomeStore, import.meta.hot));
}


