<style scoped>
.full-layout {
  width: 100%;
  max-width: 100%;
  overflow-x: hidden;
}
</style>

<template>
  
  <q-layout view="hHh lpR fFf" >
        <MenuBar />
       <ToolbarTabs/>
      <Breadcrumb />
      <router-view />
  </q-layout>
</template>

<script setup  lang="ts">
import MenuBar from 'src/components/layout/MenuBar.vue'
//import NavBar from 'src/components/layout/NavBar.vue'
import ToolbarTabs from 'src/components/layout/ToolbarTabs.vue'
import Breadcrumb from 'components/layout/Breadcrumb.vue'
</script>
