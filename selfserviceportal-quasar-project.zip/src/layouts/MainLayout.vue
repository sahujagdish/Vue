<style scoped>
.full-layout {
  width: 100%;
  max-width: 100%;
  overflow-x: hidden;
}
</style>

<template>
  
  <q-layout view="hHh lpR fFf" >
    <q-header class="bg-primary text-white">
      <q-toolbar class="q-px-md q-gutter-sm items-center justify-start">
        <!-- Logo + Title aligned left -->
        <div class="row items-center q-gutter-sm">
          <!-- <div class="text-h6">Self Service Portal</div> -->
          <!-- <q-toolbar-title>{{ $t('selfserviceportal') }}</q-toolbar-title> -->
           <MenuBar />
        </div>
        
      </q-toolbar>
    </q-header>
    <q-page-container>      
      <ToolbarTabs/>
      <Breadcrumb />
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script setup  lang="ts">
import MenuBar from 'src/components/layout/MenuBar.vue'
import ToolbarTabs from 'src/components/layout/ToolbarTabs.vue'
import Breadcrumb from 'components/layout/Breadcrumb.vue'
</script>
