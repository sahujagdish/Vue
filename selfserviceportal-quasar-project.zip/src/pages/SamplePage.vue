<template>
  <q-page class="q-pa-md column q-gutter-md">
    <!-- Name -->
    <CtlTextBox
      label="labels.name"
      v-model="name"
      :error-message="errors.name"
      :is-enable="showErrors"
      size="large"
    />

    <!-- Username -->
    <CtlTextBox
      label="labels.username"
      v-model="username"
      :minlength="6"
      :regex="usernameRegex"
      :error-message="errors.username"
      :is-enable="showErrors"
      size="medium"
    />

    <!-- Birthdate -->
    <CtlDate
      :label="t('labels.birthdate')"
      v-model="birthdate"
      :error-message="errors.birthdate"
      :is-enable="showErrors"
    />

    <!-- Favorite Fruit -->
    <CtlDropDownList
      :label="t('labels.favoriteFruit')"
      :options="['Apple', 'Banana', 'Cherry']"
      v-model="selectedFruit"
      :error-message="errors.fruit"
      :is-enable="showErrors"
    />

    <!-- Accept Terms -->
    <CtlCheckBox
      :label="t('labels.acceptTerms')"
      v-model="acceptedTerms"
      :error-message="errors.terms"
      :is-enable="showErrors"
    />

    <!-- Frameworks -->
    <CtlGroupCheckBox
      :label="t('labels.frameworks')"
      :options="['Vue', 'React', 'Angular']"
      v-model="selectedFrameworks"
      :error-message="errors.frameworks"
      :is-enable="showErrors"
    />

    <!-- Gender -->
    <CtlRadioButton
      :label="t('labels.gender')"
      :options="['Male', 'Female', 'Other']"
      v-model="gender"
      :error-message="errors.gender"
      :is-enable="showErrors"
    />

    <!-- Preferred Time -->
    <CtlGroupRadioButton
      :label="t('labels.preferredTime')"
      :options="['Morning', 'Afternoon', 'Evening']"
      v-model="preferredTime"
      :error-message="errors.time"
      :is-enable="showErrors"
    />

    <!-- Bio -->
    <CtlRichTextBox
      :label="t('labels.bio')"
      v-model="bio"
      :error-message="errors.bio"
      :is-enable="showErrors"
    />

    <!-- Submit -->
    <CtlButton :label="t('labels.submit')" @click="submitForm" />

    <!-- Banner -->
    <CtlBanner
      v-if="bannerMessage"
      :type="safeBannerType"
      :message="bannerMessage"
    />
  </q-page>
</template>

<script lang="ts" setup>
import { ref, reactive, computed } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const name = ref('')
const username = ref('')
const birthdate = ref('')
const selectedFruit = ref('')
const acceptedTerms = ref(false)
const selectedFrameworks = ref<string[]>([])
const gender = ref('')
const preferredTime = ref('')
const bio = ref('')
const usernameRegex = '^[a-zA-Z0-9_]+$'
const showErrors = ref(false)

const bannerMessage = ref('')
const bannerType = ref<'success' | 'error' | 'info' | undefined>(undefined)
const safeBannerType = computed(() => bannerType.value ?? 'info')

const errors = reactive({
  name: '',
  username: '',
  birthdate: '',
  fruit: '',
  terms: '',
  frameworks: '',
  gender: '',
  time: '',
  bio: ''
})

function submitForm(): void {
  showErrors.value = true

  errors.name = name.value ? '' : t('errors.required')

  errors.username = username.value
    ? username.value.length < 3
      ? t('errors.username.tooShort', { min: 3 })
      : username.value.length > 12
        ? t('errors.username.tooLong', { max: 12 })
        : /^[a-zA-Z0-9_]+$/.test(username.value)
          ? ''
          : t('errors.username.invalid')
    : t('errors.required')

  errors.birthdate = birthdate.value ? '' : t('errors.required')
  errors.fruit = selectedFruit.value ? '' : t('errors.fruit')
  errors.terms = acceptedTerms.value ? '' : t('errors.terms')
  errors.frameworks = selectedFrameworks.value.length ? '' : t('errors.frameworks')
  errors.gender = gender.value ? '' : t('errors.gender')
  errors.time = preferredTime.value ? '' : t('errors.time')
  errors.bio = bio.value ? '' : t('errors.bio')

  const hasErrors = Object.values(errors).some(e => !!e)

  if (hasErrors) {
    bannerMessage.value = t('errors.formBanner')
    bannerType.value = 'error'
  } else {
    bannerMessage.value = t('labels.successMessage')
    bannerType.value = 'success'
  }
}
</script>
