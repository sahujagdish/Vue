<template>
  <q-page class="q-pa-md column q-gutter-md">
    <!-- Form Section -->
    <CtlTextBox
      label="labels.name"
      v-model="name"
      :error-message="errors.name"
      :is-enable="showErrors"
      size="large"
    />
    <CtlTextBox
      label="labels.username"
      v-model="username"
      :minlength="6"
      :regex="usernameRegex"
      :error-message="errors.username"
      :is-enable="showErrors"
      size="medium"
    />
    <CtlDate
      :label="t('labels.birthdate')"
      v-model="birthdate"
      :error-message="errors.birthdate"
      :is-enable="showErrors"
    />
    <CtlDropDownList
      :label="t('labels.favoriteFruit')"
      :options="['Apple', 'Banana', 'Cherry']"
      v-model="selectedFruit"
      :error-message="errors.fruit"
      :is-enable="showErrors"
    />
    <CtlCheckBox
      :label="t('labels.acceptTerms')"
      v-model="acceptedTerms"
      :error-message="errors.terms"
      :is-enable="showErrors"
    />
    <CtlGroupCheckBox
      :label="t('labels.frameworks')"
      :options="['Vue', 'React', 'Angular']"
      v-model="selectedFrameworks"
      :error-message="errors.frameworks"
      :is-enable="showErrors"
    />
    <CtlRadioButton
      :label="t('labels.gender')"
      :options="['Male', 'Female', 'Other']"
      v-model="gender"
      :error-message="errors.gender"
      :is-enable="showErrors"
    />
    <CtlGroupRadioButton
      :label="t('labels.preferredTime')"
      :options="['Morning', 'Afternoon', 'Evening']"
      v-model="preferredTime"
      :error-message="errors.time"
      :is-enable="showErrors"
    />
    <CtlRichTextBox
      :label="t('labels.bio')"
      v-model="bio"
      :error-message="errors.bio"
      :is-enable="showErrors"
    />
    <CtlButton :label="t('labels.submit')" @click="submitForm" />
    <CtlBanner v-if="bannerMessage" :type="safeBannerType" :message="bannerMessage" />

    <!-- Grid Section -->
    <CtlLabel text="User Role" for-id="role-filter" required align="left" />
  </q-page>
  
</template>

<script setup lang="ts">
import { ref, reactive, computed } from 'vue'
import { useI18n } from 'vue-i18n'

// import type { GridRow, GridColumn } from 'src/types/components'
// import { useUserStore } from 'src/stores/user/useUserStore'
// import CtlGrid from 'src/components/controls/CtlGrid.vue'

const { t } = useI18n()
//const userStore = useUserStore()

// Form state
const name = ref('')
const username = ref('')
const birthdate = ref('')
const selectedFruit = ref('')
const acceptedTerms = ref(false)
const selectedFrameworks = ref<string[]>([])
const gender = ref('')
const preferredTime = ref('')
const bio = ref('')
const usernameRegex = '^[a-zA-Z0-9_]+$'
const showErrors = ref(false)

const bannerMessage = ref('')
const bannerType = ref<'success' | 'error' | 'info' | undefined>(undefined)
const safeBannerType = computed(() => bannerType.value ?? 'info')

const errors = reactive({
  name: '',
  username: '',
  birthdate: '',
  fruit: '',
  terms: '',
  frameworks: '',
  gender: '',
  time: '',
  bio: ''
})

function submitForm(): void {
  showErrors.value = true

  errors.name = name.value ? '' : t('errors.required')
  errors.username = username.value
    ? username.value.length < 3
      ? t('errors.username.tooShort', { min: 3 })
      : username.value.length > 12
        ? t('errors.username.tooLong', { max: 12 })
        : /^[a-zA-Z0-9_]+$/.test(username.value)
          ? ''
          : t('errors.username.invalid')
    : t('errors.required')
  errors.birthdate = birthdate.value ? '' : t('errors.required')
  errors.fruit = selectedFruit.value ? '' : t('errors.fruit')
  errors.terms = acceptedTerms.value ? '' : t('errors.terms')
  errors.frameworks = selectedFrameworks.value.length ? '' : t('errors.frameworks')
  errors.gender = gender.value ? '' : t('errors.gender')
  errors.time = preferredTime.value ? '' : t('errors.time')
  errors.bio = bio.value ? '' : t('errors.bio')

  const hasErrors = Object.values(errors).some(e => !!e)
  bannerMessage.value = hasErrors ? t('errors.formBanner') : t('labels.successMessage')
  bannerType.value = hasErrors ? 'error' : 'success'
}

// Grid state
// const gridColumns: GridColumn[] = [
//   { name: 'name', label: 'Name', field: 'name', sortable: true },
//   { name: 'role', label: 'Role', field: 'role', sortable: true }
// ]

// const sortBy = ref('')
// const descending = ref(false)
// const currentPage = ref(1)
// const pageSize = ref(10)
// const selectedRows = ref<GridRow[]>([])

// function highlightRow(row: GridRow): string {
//   return row.role === 'Admin' ? 'bg-blue-1' : ''
// }

// function onSort(col: string, desc: boolean): void {
//   sortBy.value = col
//   descending.value = desc
// }

// function onSelection(rows: GridRow[]): void {
//   selectedRows.value = rows
// }

// function onPageChange(page: number): void {
//   currentPage.value = page
// }

// function onPageSizeChange(size: number): void {
//   pageSize.value = size
//   currentPage.value = 1
// }

// function onEdit(row: GridRow): void {
//   console.log('Edit triggered:', row)
// }

// async function onUpdate(row: GridRow): Promise<void> {
//   const { status } = await userStore.dispatchUpdateUser(row)
//   if (status === 200) console.log('Updated:', row)
// }

// async function onDelete(row: GridRow): Promise<void> {
//   const { status } = await userStore.dispatchDeleteUser(row.id)
//   if (status === 200) console.log('Deleted:', row)
// }

// async function onAdd(): Promise<void> {
//   const newUser: GridRow = { id: '', name: 'New User', role: 'Guest' }
//   const { status } = await userStore.dispatchAddUser(newUser)
//   if (status === 201) {
//     currentPage.value = 1
//     onPageSizeChange(pageSize.value)
//     console.log('Added:', newUser)
//   }
// }

// async function onBulkDelete(rows: GridRow[]): Promise<void> {
//   const ids = rows.map(r => r.id)
//   const { status } = await userStore.dispatchBulkDelete(ids)
//   if (status === 200) {
//     const total = userStore.users.length - ids.length
//     const maxPage = Math.ceil(total / pageSize.value) || 1
//     currentPage.value = Math.min(currentPage.value, maxPage)
//     console.log('Bulk deleted:', ids)
//   }
// }

// onMounted(async () => {
//   const { status } = await userStore.dispatchFetchUsers()
//   if (status === 200) console.log('Users loaded:', userStore.users)
// })
</script>
