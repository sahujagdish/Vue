<template>
  <q-layout view="lHh Lpr lFf">
    <!-- Header -->
    <q-header class="bg-primary text-white">
      <q-toolbar class="q-px-md q-gutter-sm items-center justify-between">
        <!-- Left: Portal Title -->
        <div class="row items-center q-gutter-sm">
          <div class="text-h6">Self Service Portal</div>
        </div>

        <!-- Right: Language Switcher -->
        <CtlDropDownList
          label=""
          :options="localeOptions"
          :model-value="selectedLocale"
          @update:model-value="changeLocale"
          :is-enable="true"
          tooltip="Select your language"
          style="width: 100px"
        />
      </q-toolbar>
    </q-header>

    <!-- Page Content -->
    <q-page-container>
      <q-page class="flex flex-center bg-grey-2">
        <q-card class="q-pa-md" style="width: 400px">
          <q-card-section class="text-center">
            <q-img
              src="statics/transunion-cibil-logo.png"
              alt="TransUnion CIBIL"
              style="height: 60px"
              spinner-color="primary"
              class="q-mb-md"
            />
            <div class="text-h6">{{ t('login.title') }}</div>
          </q-card-section>

          <LoginForm />
        </q-card>
      </q-page>
    </q-page-container>

    <!-- Footer -->
    <q-footer class="bg-grey-3 text-grey-8 q-pa-sm text-center">
      <div class="text-caption">
        © 2024 TransUnion CIBIL. All rights reserved. Locale: {{ selectedLocale.toUpperCase() }}
      </div>
    </q-footer>
  </q-layout>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import LoginForm from 'components/login/LoginForm.vue'
import CtlDropDownList from 'components/controls/CtlDropDownList.vue'

const { locale, t } = useI18n()

const selectedLocale = ref(localStorage.getItem('locale') || 'en')

// Emoji-based country icons
const localeOptions = [
  { label: 'English', value: 'en'},
  { label: 'Français', value: 'fr'},
  { label: 'हिन्दी', value: 'hi'},
  { label: 'Português', value: 'pt'}
]

function changeLocale(newLocale: string) {
  selectedLocale.value = newLocale
  locale.value = newLocale
  localStorage.setItem('locale', newLocale)
}

onMounted(() => {
  locale.value = selectedLocale.value
})
</script>

<style scoped>
.q-header {
  height: 64px;
}
</style>
