<template>
  <q-page id="dqi-dashboard">
    <!-- Header -->
    <q-toolbar>
      <q-toolbar-title class="report-title text-center">
        {{ $t('commercialdqi.label.title') }}
      </q-toolbar-title>
    </q-toolbar>
<q-card class="q-mt-md no-export">
  <!-- Banner at the top -->
  <CtlBanner
    v-if="bannerMessage"
    :type="safeBannerType"
    :message="bannerMessage"
  />

  <q-card-section>
    <q-form @submit.prevent="handleSubmit" ref="formRef">
      <div class="row q-col-gutter-md">
        <div class="col-4 col-md-4">
           <CtlTextBox
      :label="$t('commercialdqi.label.member')"
      v-model="summary.member"
      :error-message="errors.member"
      :is-enable="showErrors"
      size="small"
      mandatory
    />
        </div>
        <div class="col-4 col-md-4">
          <CtlDate
      :label="$t('commercialdqi.label.cycle')"
      v-model="summary.cycle"
    />
          <!-- <q-input outlined v-model="summary.cycle" :label="$t('commercialdqi.label.cycle')" dense>
            <template v-slot:append>
              <q-icon name="event" class="cursor-pointer" />
              <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                <q-date v-model="summary.cycle" mask="MMMM YYYY" />
              </q-popup-proxy>
            </template>
          </q-input> -->
        </div>
        <div class="col-4 col-md-4">
          <CtlTextBox
            :label="$t('commercialdqi.label.totalBorrowers')"
            v-model="summary.totalBorrowers"
            size="small"     
            :is-enable="showErrors"
            mandatory            
          />
        </div>
      </div>

      <div class="row q-col-gutter-md">
        <div class="col-4 col-md-4">
          <CtlTextBox
            :label="$t('commercialdqi.label.totalCreditFacility')"
            v-model.number="summary.totalCreditFacility"
            size="small"
          />
        </div>
        <div class="col-4 col-md-4">
          <q-select
            v-model="summary.fileName"
            :options="fileOptions"
            :label="$t('commercialdqi.label.fileName')"
            outlined
            dense
          >
            <template v-slot:prepend><q-icon name="description" /></template>
          </q-select>
        </div>
        <div class="col-4 col-md-4">
          <q-select
            v-model="summary.portfolio"
            :options="portfolioOptions"
            :label="$t('commercialdqi.label.portfolio')"
            outlined
            dense
          >
            <template v-slot:prepend><q-icon name="folder" /></template>
          </q-select>
        </div>
      </div>

      <div class="flex justify-end q-mt-md">
        <CtlButton
          :label="$t('commercialdqi.label.submit')"
          @click="handleSubmit"
        />
      </div>
    </q-form>
  </q-card-section>
</q-card>

    <!-- Overall DQI Score + Export -->
    <q-card>
      <q-card-section>
        <div class="flex justify-between items-left">
          <table class="fixed-table">
            <tbody>
              <tr>
                <td><b>{{ $t('commercialdqi.label.member') }}</b></td>
                <td>{{ summary.member }}</td>
                <td><b>{{ $t('commercialdqi.label.cycle') }}</b></td>
                <td>{{ summary.cycle }}</td>
                <td><b>{{ $t('commercialdqi.label.totalBorrowers') }}</b></td>
                <td>{{ summary.totalBorrowers }}</td>
              </tr>
              <tr>
                <td><b>{{ $t('commercialdqi.label.totalCreditFacility') }}</b></td>
                <td>{{ summary.totalCreditFacility }}</td>
                <td><b>{{ $t('commercialdqi.label.fileName') }}</b></td>
                <td style="word-wrap: break-word; word-break: break-all;">{{ summary.fileName }}</td>
                <td><b>{{ $t('commercialdqi.label.portfolio') }}</b></td>
                <td>{{ summary.portfolio }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="flex justify-between items-center">
          <div class="text-h6">{{ $t('commercialdqi.label.dqi') }}: {{ overallDQI }}%</div>
          <div class="flex items-center no-export">
  <q-select
    v-model="exportOption"
    :options="exportOptions"
    :label="$t('commercialdqi.label.exportOptions')"
    outlined
    dense
    style="width: 180px"
  >
    <template v-slot:prepend>
      <q-icon name="download" />
    </template>
  </q-select>
<CtlButton :disable="isExporting"
    @click="handleExport"
    icon="cloud_download"/>
</div>

        </div>
        <div class="composite-bar">
          <div class="segment-fill address" :style="{ width: (addressScore / overallDQI * 100) + '%' }"></div>
          <div class="segment-fill borrower" :style="{ width: (borrowerScore / overallDQI * 100) + '%' }"></div>
          <div class="segment-fill relationship" :style="{ width: (relationshipScore / overallDQI * 100) + '%' }"></div>
          <div class="segment-fill credit" :style="{ width: (creditFacilityScore / overallDQI * 100) + '%' }"></div>
          <div class="segment-fill guarantor" :style="{ width: (guarantorScore / overallDQI * 100) + '%' }"></div>
        </div>
      </q-card-section>
      <q-inner-loading :showing="isExporting">
        <q-spinner size="50px" color="primary" />
        <div class="text-primary q-mt-md">{{ $t('commercialdqi.label.exporting') }}</div>
      </q-inner-loading>
    </q-card>

    <!-- Segment Tables -->
    <q-card class="q-mt-md">
      <q-card-section>
        <div class="pdf-container">
          <DQISegment title="Address Segment" :score="addressScore" :columns="columns" :rows="addressSegment" />
          <DQISegment title="Borrower Segment" :score="borrowerScore" :columns="columns" :rows="borrowerSegment" />
          <DQISegment title="Relationship Segment" :score="relationshipScore" :columns="columns" :rows="relationshipSegment" />
          <DQISegment title="Credit Facility Segment" :score="creditFacilityScore" :columns="columns" :rows="creditFacilitySegment" />
          <DQISegment title="Guarantor Segment" :score="guarantorScore" :columns="columns" :rows="guarantorSegment" />
        </div>
      </q-card-section>
    </q-card>

    <!-- Notes & Disclaimer -->
    <q-card class="q-mt-md">
      <q-card-section>
        <b>{{ $t('commercialdqi.label.notes') }}:</b>
        <p>{{ $t('commercialdqi.label.notesText') }}</p>
      </q-card-section>
      <q-card-section>
        <b>{{ $t('commercialdqi.label.disclaimer') }}:</b>
        <p>{{ $t('commercialdqi.label.disclaimerText') }}</p>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script lang="ts" setup>
import {reactive, ref, computed } from 'vue';
import { useQuasar } from 'quasar';
import { saveAs } from 'file-saver';
import ExcelJS from 'exceljs';
import type { Html2PdfOptions } from 'html2pdf.js';
import html2pdf from 'html2pdf.js';     
import DQISegment from '../pages/DQISegment.vue';
import { useI18n } from 'vue-i18n';

interface Summary {
  member: string;
  cycle: string;
  totalBorrowers: number;
  totalCreditFacility: number;
  fileName: string;
  portfolio: string;
}

interface SegmentRow {
  category: string;
  weight: number;
  actual: number;
  score: number;
  invalid: number;
}

// export default defineComponent({
//   name: 'Dqidashboard',
//   components: { DQISegment },
//   setup() {
    const { t } = useI18n();
    const $q = useQuasar();

    const bannerMessage = ref('')
    const bannerType = ref<'success' | 'error' | 'info' | undefined>(undefined)
    const safeBannerType = computed(() => bannerType.value ?? 'info')
    const showErrors = ref(false)
    const errors = reactive({
      member: '',
    })  

    const summary = ref<Summary>({
      member: 'PUNJAB NATIONAL BANK',
      cycle: 'NOVEMBER 2025',
      totalBorrowers: 1098,
      totalCreditFacility: 1326,
      fileName: '14112025-CIC_COMMERCIAL_FILEDATA_DAILY.txt',
      portfolio: 'DAILY_DATA'
    });

    const fileOptions: string[] = ['14112025-CIC_COMMERCIAL_FILEDATA_DAILY.txt'];
    const portfolioOptions: string[] = ['DAILY_DATA'];
    const exportOptions: string[] = ['Export to Excel', 'Export to PDF'];
    const exportOption = ref<string>('');

    //const submitted = ref<boolean>(false);
    const isExporting = ref<boolean>(false);
    
    

    const overallDQI = 89.48;
    const columns: string[] = [
      t('commercialdqi.tableHeaders.category'),
      t('commercialdqi.tableHeaders.weight'),
      t('commercialdqi.tableHeaders.actual'),
      t('commercialdqi.tableHeaders.score'),
      t('commercialdqi.tableHeaders.invalid')
    ];

    const addressScore = 14.59;
    const borrowerScore = 16.27;
    const relationshipScore = 15.38;
    const creditFacilityScore = 33.95;
    const guarantorScore = 9.28;

    const addressSegment: SegmentRow[] = [
      { category: 'Address', weight: 3, actual: 99.54, score: 2.9862, invalid: 5 },
      { category: 'City', weight: 3, actual: 97.72, score: 2.9316, invalid: 25 },
      { category: 'Pin code', weight: 3, actual: 98.54, score: 2.9562, invalid: 16 },
      { category: 'State code', weight: 3, actual: 99.45, score: 2.9835, invalid: 6 },
      { category: 'Telephone/Mobile', weight: 3, actual: 91.17, score: 2.7351, invalid: 97 }
    ];

    const borrowerSegment: SegmentRow[] = [
      { category: 'Business Category', weight: 2, actual: 62.66, score: 1.2532, invalid: 410 },
      { category: 'PAN/CIN/TIN/Other IDs', weight: 10, actual: 79.96, score: 7.996, invalid: 220 },
      { category: 'Class of activity', weight: 2, actual: 64.75, score: 1.295, invalid: 387 },
      { category: 'Industry Type', weight: 2, actual: 87.07, score: 1.7414, invalid: 142 },
      { category: 'Legal Constitution', weight: 4, actual: 99.73, score: 3.9892, invalid: 3 }
    ];

    const relationshipSegment: SegmentRow[] = [
      { category: 'Address', weight: 2, actual: 86.96, score: 1.7392, invalid: 135 },
      { category: 'CITY', weight: 2, actual: 85.31, score: 1.7062, invalid: 152 },
      { category: 'PAN/CIN/Passport/DIN', weight: 5, actual: 80.48, score: 4.024, invalid: 202 },
      { category: 'Pin code', weight: 2, actual: 86.67, score: 1.7334, invalid: 138 },
      { category: 'State code', weight: 2, actual: 86.96, score: 1.7392, invalid: 135 },
      { category: 'Related Type+Relationship', weight: 5, actual: 54.98, score: 2.749, invalid: 466 },
      { category: 'Telephone/Mobile', weight: 2, actual: 84.35, score: 1.687, invalid: 162 }
    ];

    const creditFacilitySegment: SegmentRow[] = [
      { category: 'Credit Type', weight: 8, actual: 99.32, score: 7.9456, invalid: 9 },
      { category: 'DPD or Asset Class', weight: 8, actual: 100, score: 8, invalid: 0 },
      { category: 'Facility / Loan Activation Date', weight: 3, actual: 100, score: 3, invalid: 0 },
      { category: 'Suit Filed Fields', weight: 3, actual: 66.82, score: 2.0046, invalid: 440 },
      { category: 'Wilful Default fields', weight: 3, actual: 100, score: 3, invalid: 0 },
      { category: 'Account Status', weight: 10, actual: 100, score: 10, invalid: 0 }
    ];

    const guarantorSegment: SegmentRow[] = [
      { category: 'Address', weight: 3, actual: 100, score: 3, invalid: 0 },
      { category: 'CITY', weight: 2, actual: 97.69, score: 1.9538, invalid: 7 },
      { category: 'PAN/CIN/PASSPORT/DIN', weight: 3, actual: 78.55, score: 2.3565, invalid: 65 },
      { category: 'Pin code + State code', weight: 2, actual: 98.68, score: 1.9736, invalid: 4 }
    ];

 const handleSubmit = (): void => {

    //submitted.value = !submitted.value;
  // Reset banner
  bannerMessage.value = ''
  bannerType.value = 'info'

  showErrors.value = true

  errors.member = summary.value.member ? '' : t('errors.required')
  
const hasErrors = Object.values(errors).some(e => !!e)
  bannerMessage.value = hasErrors ? t('errors.formBanner') : t('commercialdqi.errors.successMessage')
  bannerType.value = hasErrors ? 'error' : 'success'
};

    const handleExport = async (): Promise<void> => {
      if (!exportOption.value) {
        $q.notify({ type: 'warning', message: t('commercialdqi.label.selectExportOption') });
        return;
      }
      isExporting.value = true;
      try {
        if (exportOption.value === 'Export to Excel') {
          await exportExcel();
        } else if (exportOption.value === 'Export to PDF') {
          await exportPDF();
        }
        $q.notify({ type: 'positive', message: `${exportOption.value} ${t('commercialdqi.errors.successMessage')}` });
      } catch (error: unknown) {
        const message = error instanceof Error ? error.message : String(error);
        $q.notify({ type: 'negative', message: `${t('exportFailed')}: ${message}` });
      } finally {
        isExporting.value = false;
      }
    };

    const exportExcel = async (): Promise<void> => {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('DQI');
      worksheet.mergeCells('A1:K1');
      const titleCell = worksheet.getCell('A1');
      titleCell.value = t('title');
      titleCell.font = { size: 16, bold: true, color: { argb: 'FFFFFF' } };
      titleCell.alignment = { horizontal: 'center' };
      titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '0B5394' } };

      worksheet.addRow([]);
      const rows = [
        [t('commercialdqi.label.member'), summary.value.member],
        [t('commercialdqi.label.cycle'), summary.value.cycle],
        [t('commercialdqi.label.totalBorrowers'), summary.value.totalBorrowers],
        [t('commercialdqi.label.totalCreditFacility'), summary.value.totalCreditFacility],
        [t('commercialdqi.label.fileName'), summary.value.fileName],
        [t('commercialdqi.label.portfolio'), summary.value.portfolio],
        [t('dqi'), `${overallDQI}%`]
      ];
      rows.forEach(r => worksheet.addRow(r));

      const buffer = await workbook.xlsx.writeBuffer();
      saveAs(new Blob([buffer]), `Commercial_DQI_${summary.value.member}.xlsx`);
    };

    const exportPDF = async (): Promise<void> => {
       const element = document.querySelector('#dqi-dashboard');
  if (!(element instanceof HTMLElement)) {
    $q.notify({ type: 'negative', message: 'Dashboard element not found!' });
    return;
  }
      const options: Html2PdfOptions = {
        margin: [2, 2, 5, 5],
        filename: `DQI_Commercial_${summary.value.member}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, scrollX: 0, scrollY: 0 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
        pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
      };
      try {
        document.querySelectorAll('.no-export').forEach(el => (el as HTMLElement).style.display = 'none');
        await html2pdf().set(options).from(element).save();
        $q.notify({ type: 'positive', message: t('commercialdqi.errors.exportSuccess') });
      } catch (error: unknown) {
        const message = error instanceof Error ? error.message : String(error);
        $q.notify({ type: 'negative', message: `${t('exportFailed')}: ${message}` });
      } finally {
        document.querySelectorAll('.no-export').forEach(el => (el as HTMLElement).style.display = '');
      }
    };

//     return {
//       t,
//       summary,
//       fileOptions,
//       portfolioOptions,
//       exportOptions,
//       exportOption,
//       submitted,
//       isExporting,
//       overallDQI,
//       columns,
//       addressScore,
//       borrowerScore,
//       relationshipScore,
//       creditFacilityScore,
//       guarantorScore,
//       addressSegment,
//       borrowerSegment,
//       relationshipSegment,
//       creditFacilitySegment,
//       guarantorSegment,
//       handleSubmit,
//       handleExport,
//       bannerMessage,
//       safeBannerType,
//       showErrors,
//       errors
//     };
//   }
// });
</script>

<style scoped>
.summary-grid {
  display: flex;
  flex-wrap: wrap;
}
.fixed-table td {
  padding: 4px 8px;
}
.composite-bar {
  display: flex;
  height: 20px;
  margin-top: 10px;
}
.segment-fill {
  height: 100%;
}
.segment-fill.address { background-color: #4caf50; }
.segment-fill.borrower { background-color: #2196f3; }
.segment-fill.relationship { background-color: #ff9800; }
.segment-fill.credit { background-color: #9c27b0; }
.segment-fill.guarantor { background-color: #f44336; }
</style>


<style scoped>
.summary-grid {
  display: flex;
  flex-wrap: wrap;
}
.fixed-table td {
  padding: 4px 8px;
}
.composite-bar {
  display: flex;
  height: 20px;
  margin-top: 10px;
}
.segment-fill {
  height: 100%;
}
.segment-fill.address { background-color: #4caf50; }
.segment-fill.borrower { background-color: #2196f3; }
.segment-fill.relationship { background-color: #ff9800; }
.segment-fill.credit { background-color: #9c27b0; }
.segment-fill.guarantor { background-color: #f44336; }
</style>

<style>
/* ===== Summary Section ===== */
.summary-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  margin-top: 8px;
}

.q-input,
.q-select {
  width: 100%;
}

/* ===== Composite Bar ===== */
.composite-bar {
  display: flex;
  width: 100%;
  height: 14px;
  border-radius: 6px;
  overflow: hidden;
  margin-top: 8px;
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.2);
}

.segment-fill {
  height: 100%;
}

.address {
  background-color: #007bff;
}

/* Blue */
.borrower {
  background-color: #fd7e14;
}

/* Orange */
.relationship {
  background-color: #28a745;
}

/* Green */
.credit {
  background-color: #6f42c1;
}

/* Purple */
.guarantor {
  background-color: #20c997;
}

/* Teal */

/* ===== Table Layout ===== */
.pdf-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 5px;
  margin-top: 5px;
}

.table-container {
  width: 100%;
}

.segment-label {
  font-weight: bold;
  margin: 6px 0;
  font-size: 14px;
  color: #333;
}

/* ===== Table Styling ===== */
.dqi-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.dqi-table th {
  background-color: #007bff;
  /* Blue header */
  color: #fff;
  font-weight: bold;
  padding: 6px 8px;
  text-align: left;
}

.dqi-table td {
  border: 1px solid #ccc;
  padding: 4px 8px;
  background-color: #fff;
  color: #000;
}

.dqi-table tr {
  height: 28px;
}

/* ===== Loading Spinner Overlay ===== */
.q-inner-loading {
  background-color: rgba(255, 255, 255, 0.8);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.q-inner-loading .text-primary {
  font-size: 14px;
  font-weight: 500;
}

/* ===== Notes & Disclaimer ===== */
.q-card-section p {
  font-size: 13px;
  color: #555;
  line-height: 1.4;
}

/* ===== Responsive Adjustments ===== */
@media (max-width: 1024px) {
  .summary-grid {
    grid-template-columns: 1fr 1fr;
  }

  .pdf-container {
    grid-template-columns: 1fr;
  }
}

.report-title {
  background-color: #0B5394;
  color: white;
  font-size: 30px;
  font-weight: bold;
  padding: 0px 0px 0px 0px;
  margin: 0 0 0 0;
}

.submit {
  background-color: #0B5394 !important;
  color: white !important;
  font-size: 20px;
  font-weight: bold;
  padding: 1px 2px;
  text-align: center;
}

@media (max-width: 768px) {
  .summary-grid {
    grid-template-columns: 1fr;
  }
}

/* Avoid breaking inside these blocks */
.page-break-inside {
  page-break-inside: avoid;
}

*/

/* Ensure dashboard fits A4 width */
#dqi-dashboard {
  width: 794px;
  /* A4 width in pixels at 96 DPI */
  max-width: 794px;
}

.enable-hidden-export {
  display: none !important;
}

.no-export {
  display: '' !important;
}

.q-card-section top {
  padding-top: 2px;
}

.q-card-section bottom {
  padding-top: 2px;
}

.fixed-table {
  width: 100%;
}

.fixed-table td:nth-child(1),
.fixed-table th:nth-child(1) {
  width: 10%;
}

.fixed-table td:nth-child(2),
.fixed-table th:nth-child(2) {
  width: 20%;
}

.fixed-table td:nth-child(3),
.fixed-table th:nth-child(3) {
  width: 10%;
}

.fixed-table td:nth-child(4),
.fixed-table th:nth-child(4) {
  width: 35%;
}

.fixed-table td:nth-child(5),
.fixed-table th:nth-child(5) {
  width: 10%;
}

.fixed-table td:nth-child(6),
.fixed-table th:nth-child(6) {
  width: 20%;
}


.export-hidden {
  position: absolute;
  left: -9999px;
  top: 0;
}


@media print {
  .no-export {
    display: none !important;
  }

  .enable-hidden-export {
    display: '' !important;
  }

  .left-align-table {
    float: left;
    /* or margin-left: 0; */
  }
}
</style>

