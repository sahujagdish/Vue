<style lang="css">
.container {
  margin: auto;
  background: #fff;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

h3 {
  text-align: center;
  margin-bottom: 30px;
  color: #0b3d91;
}

.filters {
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 20px;
  background-color: #fff;
  margin-bottom: 20px;
}

.form-row {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
}

.form-row label {
  width: 250px;
  font-weight: bold;
}

.radio-group {
  display: flex;
  align-items: center;
  gap: 20px;
}

select {
  height: 30px;
  padding-left: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #f9f9f9;
  font-size: 14px;
  color: #333;
  appearance: none;
  outline: none;
  transition: border 0.3s, box-shadow 0.3s;
  background-image: url("data:image/svg+xml;utf8,<svg fill='%23333' height='20' viewBox='0 0 24 24' width='20' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>");
  background-repeat: no-repeat;
  background-position: right 10px center;
  background-size: 16px;
  padding-right: 35px;
}

select:focus {
  border-color: #1877f2;
  box-shadow: 0 0 6px rgba(24, 119, 242, 0.3);
  background-color: #fff;
}

button {
  padding: 10px 20px;
  background-color: #0b3d91;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #092b66;
}

.report {
  margin-top: 20px;
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 20px;
  background-color: #fff;
}

#dqitable {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
  border: 1px solid black;
}

#dqitable th,
#dqitable td {
  border: 1px solid black;
  padding: 6px;
  font-size: 15px;
  vertical-align: middle;
}

#dqitable th {
  background-color: #0b3d91;
  color: white;
  text-align: center;
}

#dqitable td:nth-child(2),
#dqitable td:nth-child(3),
#dqitable td:nth-child(4) {
  text-align: center;
}

#dqitable th[colspan="4"] {
  text-align: center;
  font-weight: bold;
  background-color: #f0f0f0;
}

.score-row {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 48%;
  margin-top: 20px;
  margin-left: 6px;
}

#scoretextdiv {
  background-color: #f08000;
  color: black;
  font-weight: bold;
  text-align: center;
  font-size: 20px;
  height: 30px;
  width: 80%;
  display: flex;
  justify-content: center;
  align-items: center;
}

#scorediv {
  width: 20%;
  text-align: center;
  background-color: #f08000;
  color: black;
  font-weight: bold;
  font-size: 20px;
  height: 30px;
  display: flex;
  justify-content: center;
  align-items: center;
}

</style>
<template>
  <div class="container">
    <h3>{{ t('dqi.labels.reportTitle') }}</h3>

    <!-- Filters -->
    <div class="filters">
      <div class="form-row">
        <label>{{ t('dqi.labels.reportView') }}</label>
        <div class="radio-group">
          <input type="radio" id="consolidated" value="Consolidated" v-model="reportView" />
          <label for="consolidated">{{ t('dqi.labels.consolidated') }}</label>
          <input type="radio" id="portfolio" value="Portfolio" v-model="reportView" />
          <label for="portfolio">{{ t('dqi.labels.portfolio') }}</label>
        </div>
      </div>

      <div class="form-row">
        <label>{{ t('dqi.labels.cycle') }}</label>
        <select v-model="selectedCycle">
          <option value="">--Select--</option>
          <option v-for="cycle in cycles" :key="cycle" :value="cycle">{{ cycle }}</option>
        </select>
      </div>

      <div class="form-row">
        <label>{{ t('dqi.labels.portfolioLabel') }}</label>
        <select v-model="selectedPortfolio">
          <option value="">--Select--</option>
          <option v-for="portfolio in portfolios" :key="portfolio" :value="portfolio">{{ portfolio }}</option>
        </select>
      </div>

      <div class="form-row">
        <label>{{ t('dqi.labels.fileName') }}</label>
        <select v-model="selectedFileName">
          <option value="All">All</option>
          <option v-for="file in fileNames" :key="file" :value="file">{{ file }}</option>
        </select>
      </div>

      <div class="form-row">
        <button @click="getData">{{ t('dqi.labels.getData') }}</button>
      </div>
    </div>

    <!-- Table -->
    <div class="report">
      <label class="text-bold text-lg">{{ t('dqi.labels.tableTitle') }}</label>
      <table id="dqitable">
        <thead>
          <tr class="bg-blue">
            <th>{{ t('dqi.labels.category') }}</th>
            <th>{{ t('dqi.labels.weight') }}</th>
            <th>{{ t('dqi.labels.weightedPercentage') }}</th>
            <th>{{ t('dqi.labels.actualPercentage') }}</th>
          </tr>
        </thead>
        <tbody>
          <tr><th colspan="4">{{ t('dqi.labels.segmentA') }}</th></tr>
          <tr><td>{{ t('dqi.labels.fields.name') }}</td><td>20%</td><td>{{ data.nameWeighted }}</td><td>{{ data.nameActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.dob') }}</td><td>20%</td><td>{{ data.dobWeighted }}</td><td>{{ data.dobActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.pan') }}</td><td rowspan="3">20%</td><td rowspan="3">{{ data.panWeighted }}</td><td rowspan="3">{{ data.panActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.voterId') }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.uid') }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.pincode') }}</td><td>20%</td><td>{{ data.pincodeWeighted }}</td><td>{{ data.pincodeActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.phone') }}</td><td>20%</td><td>{{ data.phoneWeighted }}</td><td>{{ data.phoneActual }}</td></tr>

          <tr><th colspan="4">{{ t('dqi.labels.segmentB') }}</th></tr>
          <tr><td>{{ t('dqi.labels.fields.dpd') }}</td><td>20%</td><td>{{ data.dpdWeighted }}</td><td>{{ data.dpdActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.sanction') }}</td><td>20%</td><td>{{ data.sanctionWeighted }}</td><td>{{ data.sanctionActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.opened') }}</td><td>20%</td><td>{{ data.openedWeighted }}</td><td>{{ data.openedActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.balance') }}</td><td>20%</td><td>{{ data.balanceWeighted }}</td><td>{{ data.balanceActual }}</td></tr>
          <tr><td>{{ t('dqi.labels.fields.accountType') }}</td><td>20%</td><td>{{ data.accountTypeWeighted }}</td><td>{{ data.accountTypeActual }}</td></tr>
        </tbody>
      </table>
    </div>

    <!-- Score -->
    <div class="score-row">
      <div id="scoretextdiv">{{ t('dqi.labels.scoreLabel') }}</div>
      <div id="scorediv">{{ data.score }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const reportView = ref('Consolidated')
const selectedCycle = ref('')
const selectedPortfolio = ref('')
const selectedFileName = ref('All')

const cycles = ref(['Jun 2025', 'Mar 2025'])
const portfolios = ref(['Retail', 'Corporate'])
const fileNames = ref(['DQI_Report_1.csv', 'DQI_Report_2.csv'])

const data = ref({
  nameWeighted: '95%',
  nameActual: '92%',
  dobWeighted: '90%',
  dobActual: '88%',
  panWeighted: '85%',
  panActual: '80%',
  pincodeWeighted: '91%',
  pincodeActual: '89%',
  phoneWeighted: '88%',
  phoneActual: '84%',
  dpdWeighted: '86%',
  dpdActual: '82%',
  sanctionWeighted: '87%',
  sanctionActual: '83%',
  openedWeighted: '89%',
  openedActual: '85%',
  balanceWeighted: '90%',
  balanceActual: '86%',
  accountTypeWeighted: '92%',
  accountTypeActual: '88%',
  score: '89.7%'
})

function getData() {
  // fetch logic placeholder
}
</script>

<style scoped>
/* Paste your full CSS here from earlier */
</style>
