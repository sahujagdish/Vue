<template>
  <table class="dqi-table">
    <thead>
      <tr>
        <th v-for="col in columns" :key="col">
          {{ col }}
        </th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="(row, rIdx) in rows" :key="rIdx">
        <td v-for="col in columns" :key="col">
          <!-- ✅ Safe lookup: if col not in colMap, show empty -->
          {{ colMap[col] ? row[colMap[col] as keyof Row] ?? '' : '' }}
        </td>
      </tr>
    </tbody>
  </table>
</template>

<script lang="ts" setup>
/**
 * Strict Row type — explicit keys, no `any`.
 */
interface Row {
  category: string | number;
  weight: string | number;
  actual: string | number;
  score: string | number;
  invalid: string | number;
}

/**
 * Props — columns can be any string[], rows are strictly typed.
 */
defineProps<{
  columns: string[];
  rows: Row[];
}>();

/**
 * Map display column names to actual row keys.
 */
const colMap: Record<string, keyof Row> = {
  'Category': 'category',
  'Weight': 'weight',
  'Actual %': 'actual',
  'Score': 'score',
  'Invalid': 'invalid'
};
</script>

<style scoped>
.dqi-table {
  border-collapse: collapse;
  font-size: 12px;
}
.dqi-table th {
  background-color: #0B5394;
  color: white;
  font-weight: bold;
  padding: 6px 8px;
  text-align: left;
}
.dqi-table td {
  border: 1px solid #ccc;
  padding: 2px 6px;
  background-color: #fff;
  color: #000;
}
.dqi-table tr {
  height: 24px;
}
</style>
