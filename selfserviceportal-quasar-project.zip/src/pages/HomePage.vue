<template>
    <ThemeSwitcher />
  <q-page class="q-pa-md">
    <q-form @submit.prevent="handleSubmit" ref="formRef">
      <q-input v-model="form.id" :label="$t('id')" :rules="[required]" />
      <q-input v-model="form.name" :label="$t('name')" :rules="[required]" />
      <q-input v-model="form.age" :label="$t('age')" type="number" :rules="[required, isNumber]" />
      <q-select
        v-model="form.gender"
        :label="$t('gender')"
        :options="genderOptions"
        :rules="[required]"
      />
      <q-btn :label="$t('submit')" type="submit" color="primary" />
    </q-form>
  </q-page>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { useHomeStore } from 'stores/homeStore'
import type { FormData } from 'src/types'
import ThemeSwitcher from 'src/components/layout/LocaleThemeSwitcher.vue'

const form = ref<FormData>({
  id: '',
  name: '',
  age: 0,
  gender: 'male'
})


const { t } = useI18n()
const homeStore = useHomeStore()
const formRef = ref()

const genderOptions = [
  { label: t('male'), value: 'male' },
  { label: t('female'), value: 'female' }
]

const required = (val: string | number): boolean | string => !!val || t('validation.required')
const isNumber = (val: string | number): boolean | string => !isNaN(Number(val)) || t('validation.age')


function handleSubmit() {
  if (formRef.value?.validate()) {
    homeStore.submitForm(form.value)
  }
}
</script>
