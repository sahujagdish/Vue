<template>
  <div class="table-container">
    <h6 class="segment-label">{{ title }} (Score: {{ score }})</h6>
    <!-- ✅ Pass strictly typed props down -->
    <DQITable :columns="columns" :rows="rows" />
  </div>
</template>

<script lang="ts" setup>
import DQITable from './DQITable.vue';

/**
 * Strict Row type — matches the keys used in DQITable.
 * No `any` anywhere.
 */
interface Row {
  category: string | number;
  weight: string | number;
  actual: string | number;
  score: string | number;
  invalid: string | number;
}

/**
 * Type-only mapping of display column names to row keys.
 * This avoids creating an unused runtime variable.
 */
// type ColMap = {
//   'Category': 'category';
//   'Weight': 'weight';
//   'Actual %': 'actual';
//   'Score': 'score';
//   'Invalid': 'invalid';
// };

defineProps<{
  title: string;
  score: number;
  columns: string[]; //(keyof ColMap)[];
  rows: Row[];
}>();
</script>

<style scoped>
.table-container {
  width: 100%;
  text-align: left;
}
.segment-label {
  font-weight: bold;
  margin: 4px 0;
  font-size: 14px;
  color: #333;
}
</style>
