<template>
  <div class="container">
    <h3>{{ t('dqi.labels.reportTitle') }}</h3>

    <!-- Filters -->
    <div class="filters">
      <div class="form-row">
        <label>{{ t('dqi.labels.reportView') }}</label>
        <div class="radio-group">
          <input type="radio" id="consolidated" value="Consolidated" v-model="reportView" />
          <label for="consolidated">{{ t('dqi.labels.consolidated') }}</label>
          <input type="radio" id="portfolio" value="Portfolio" v-model="reportView" />
          <label for="portfolio">{{ t('dqi.labels.portfolio') }}</label>
        </div>
      </div>

      <div class="form-row">
        <label>{{ t('dqi.labels.cycle') }}</label>
        <select v-model="selectedCycle">
          <option value="">--Select--</option>
          <option v-for="cycle in cycles" :key="cycle" :value="cycle">{{ cycle }}</option>
        </select>
      </div>

      <div class="form-row">
        <label>{{ t('dqi.labels.portfolioLabel') }}</label>
        <select v-model="selectedPortfolio">
          <option value="">--Select--</option>
          <option v-for="portfolio in portfolios" :key="portfolio" :value="portfolio">{{ portfolio }}</option>
        </select>
      </div>

      <div class="form-row">
        <label>{{ t('dqi.labels.fileName') }}</label>
        <select v-model="selectedFileName">
          <option value="All">All</option>
          <option v-for="file in fileNames" :key="file" :value="file">{{ file }}</option>
        </select>
      </div>
      <div class="row justify-center items-center" style="height: 100%">
  <button @click="getData">{{ t('dqi.labels.getData') }}</button>
</div>
    </div>

    <!-- Loading -->
    <div v-if="isLoading" class="loading">{{ t('dqi.labels.loading') }}</div>

    <!-- Table + Summary Panel -->
    <div v-else class="table-panel-wrapper">
      <div class="table-container">
        <div class="table-header-row">
          <label class="table-title">{{ t('dqi.labels.tableTitle') }}</label>
          <div class="score-row">
            <div id="scoretextdiv">{{ t('dqi.labels.scoreLabel') }}</div>
            <div id="scorediv">{{ score }}</div>
          </div>
        </div>

        <table id="dqitable">
          <thead>
            <tr>
              <th>{{ t('dqi.labels.category') }}</th>
              <th>{{ t('dqi.labels.weight') }}</th>
              <th>{{ t('dqi.labels.weightedPercentage') }}</th>
              <th>{{ t('dqi.labels.actualPercentage') }}</th>
            </tr>
          </thead>
          <tbody>
            <tr><th colspan="4">{{ t('dqi.labels.segmentA') }}</th></tr>
            <tr><td>{{ t('dqi.labels.fields.name') }}</td><td>20%</td><td>{{ get('nameWeighted') }}</td><td>{{ get('nameActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.dob') }}</td><td>20%</td><td>{{ get('dobWeighted') }}</td><td>{{ get('dobActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.pan') }}</td><td rowspan="3">20%</td><td rowspan="3">{{ get('panWeighted') }}</td><td rowspan="3">{{ get('panActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.voterId') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.uid') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.pincode') }}</td><td>20%</td><td>{{ get('pincodeWeighted') }}</td><td>{{ get('pincodeActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.phone') }}</td><td>20%</td><td>{{ get('phoneWeighted') }}</td><td>{{ get('phoneActual') }}</td></tr>

            <tr><th colspan="4">{{ t('dqi.labels.segmentB') }}</th></tr>
            <tr><td>{{ t('dqi.labels.fields.dpd') }}</td><td>20%</td><td>{{ get('dpdWeighted') }}</td><td>{{ get('dpdActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.sanction') }}</td><td>20%</td><td>{{ get('sanctionWeighted') }}</td><td>{{ get('sanctionActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.opened') }}</td><td>20%</td><td>{{ get('openedWeighted') }}</td><td>{{ get('openedActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.balance') }}</td><td>20%</td><td>{{ get('balanceWeighted') }}</td><td>{{ get('balanceActual') }}</td></tr>
            <tr><td>{{ t('dqi.labels.fields.accountType') }}</td><td>20%</td><td>{{ get('accountTypeWeighted') }}</td><td>{{ get('accountTypeActual') }}</td></tr>
          </tbody>
        </table>
      </div>

      <!-- Toggle Button -->
      <button class="toggle-button-vertical" @click="isCollapsed = !isCollapsed">
        <span class="icon">{{ isCollapsed ? '▶' : '◀' }}</span>
        <span class="label">
          {{ isCollapsed ? t('dqi.labels.showSummary') : t('dqi.labels.hideSummary') }}
        </span>
      </button>

      <!-- Summary Panel -->
      <div v-if="!isCollapsed" class="summary-panel">
        <div class="summary-content">
          <h4>{{ t('dqi.labels.summaryTitle') }}</h4>
          <div class="summary-scroll">
            <p>{{ longSummary }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { useDqiStore } from '../stores/dqi/dqiStore'

const { t } = useI18n()
const dqiStore = useDqiStore()

const reportView = ref('Consolidated')
const selectedCycle = ref('')
const selectedPortfolio = ref('')
const selectedFileName = ref('All')

const cycles = ref(['Jun 2025', 'Mar 2025'])
const portfolios = ref(['Retail', 'Corporate'])
const fileNames = ref(['DQI_Report_1.csv', 'DQI_Report_2.csv'])

const score = computed(() => dqiStore.getScore)
const get = (field: keyof typeof dqiStore.report) => dqiStore.getFieldWeighted(field)

const isLoading = ref(false)
const isCollapsed = ref(false)
const longSummary = ref('Your full 3000-word summaryewiryuyuryeiuwyrewyruewyrewyury hieurueyryeryewiuy yiyuiyyyyiyuiyyiuyyiu iuiyyiyiuyyiy iyyyiuyuiy ewtrtrtweutry uttuytt tyutttttututtututttytytytuytyt goes here...') // Replace with actual content

async function getData() {
  isLoading.value = true
  await dqiStore.dispatchGetReport({
    reportView: reportView.value,
    cycle: selectedCycle.value,
    portfolio: selectedPortfolio.value,
    fileName: selectedFileName.value
  })
  isLoading.value = false
}

onMounted(() => {
  const noFiltersSelected =
    !selectedCycle.value && !selectedPortfolio.value && selectedFileName.value === 'All'

  if (noFiltersSelected) {
    dqiStore.dispatchDefaultReport()
  }
})
</script>

<style scoped>
.container {
  max-width: 960px;
  margin: 0 auto;
  padding: 1.5rem;
  background: #fff;
  border-radius: 6px;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.06);
}

h3 {
  text-align: center;
  font-size: 20px;
  font-weight: 600;
  color: #0b3d91;
  margin-bottom: 1rem;
}

.filters {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin-bottom: 1.5rem;
  padding: 1rem;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #f8f8f8;
  align-items: flex-end;
}

.form-row {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  min-width: 160px;
}

.form-row label {
  font-weight: 500;
  font-size: 13px;
  color: #333;
}

select,
input[type="radio"] {
  font-size: 13px;
  padding: 5px 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #fff;
}

.radio-group {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

button {
  padding: 6px 12px;
  background-color: #0b3d91;
  color: #fff;
  border: none;
  border-radius: 4px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
}

button:hover {
  background-color: #092b66;
}

.loading {
  text-align: center;
  font-weight: 500;
  font-size: 14px;
  color: #0b3d91;
  margin-top: 1rem;
}

.table-panel-wrapper {
  display: flex;
  align-items: stretch;
  gap: 1rem;
  position: relative;
}

.table-container {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.table-header-row {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 0.5rem;
  padding-inline: 0.25rem;
}

.table-title {
  font-size: 15px;
  font-weight: 600;
  color: #0b3d91;
  margin: 0;
}

.score-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 13px;
}

#scoretextdiv {
  font-weight: 500;
  color: #333;
}

#scorediv {
  background-color: #0b3d91;
  color: #fff;
  padding: 4px 10px;
  border-radius: 4px;
  font-weight: 600;
}

#dqitable {
  flex-grow: 1;
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

#dqitable th,
#dqitable td {
  border: 1px solid #ccc;
  padding: 8px;
  text-align: center;
}

#dqitable th {
  background-color: #f0f4f8;
  font-weight: 600;
}

#dqitable tr:nth-child(even) {
  background-color: #f9f9f9;
}

.toggle-button-vertical {
  position: absolute;
  top: 1rem;
  right: -40px;
  background-color: #0b3d91;
  color: #fff;
  border: none;
  border-radius: 4px;
  padding: 6px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  z-index: 1;
}

.toggle-button-vertical .icon {
  font-size: 14px;
}

.toggle-button-vertical .label {
  writing-mode: vertical-rl;
  transform: rotate(180deg);
  text-align: center;
}

.summary-panel {
  width: 300px;
  border: 1px solid #ccc;
  border-radius: 6px;
  background-color: #f9f9f9;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  height: auto;
  max-height: 100%;
}

.summary-content {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  padding: 1rem;
}

.summary-content h4 {
  font-size: 14px;
  margin-bottom: 0.5rem;
  color: #0b3d91;
}

.summary-scroll {
  overflow-y: auto;
  flex-grow: 1;
  font-size: 13px;
  line-height: 1.5;
  white-space: pre-wrap;
  padding-right: 6px;
}

</style>