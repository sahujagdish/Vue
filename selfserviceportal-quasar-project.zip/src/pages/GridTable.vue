<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useGridStore, type Item } from 'src/stores/tickets/grid'
import type { QTableColumn, QTableProps } from 'quasar'

const gridStore = useGridStore()

// IMPORTANT: column.name must match Item keys so sortBy maps to keyof Item
const columns: QTableColumn[] = [
  { name: 'id', label: 'ID', field: 'id', align: 'left', sortable: true },
  { name: 'name', label: 'Name', field: 'name', align: 'left', sortable: true }
]

const rows = ref<Item[]>([])
const pagination = ref({
  page: 1,
  rowsPerPage: 5,
  rowsNumber: 0
})

function onRequest(props: { pagination?: QTableProps['pagination'] }) {
  const { page, rowsPerPage, sortBy, descending } = props.pagination ?? {}

  // Map sortBy (column.name) directly to Item key (ensure names match)
  const safeSortBy = (sortBy ?? gridStore.sortBy) as keyof Item

  const safePage = page ?? pagination.value.page
  const safeRowsPerPage = rowsPerPage ?? pagination.value.rowsPerPage
  const safeDescending = descending ?? gridStore.descending

  // Refresh rows based on latest controls
  rows.value = gridStore.fetchData(safePage, safeRowsPerPage, safeSortBy, safeDescending)

  // Update pagination (only allowed fields)
  pagination.value = {
    page: safePage,
    rowsPerPage: safeRowsPerPage,
    rowsNumber: gridStore.rows.length
  }

  // Persist sort state in store
  gridStore.sortBy = safeSortBy
  gridStore.descending = safeDescending
}

onMounted(() => {
  gridStore.initMockData()
  // Trigger initial load
  onRequest({ pagination: { page: 1, rowsPerPage: 5, rowsNumber: gridStore.rows.length } })
})
</script>

<template>
  <q-table
    v-model:pagination="pagination"
    :rows="rows"
    :columns="columns"
    row-key="id"
    @request="onRequest"
  >
    <template v-slot:body-cell-id="props">
      <q-td :props="props">
        {{ props.value }}
      </q-td>
    </template>

    <template v-slot:body-cell-name="props">
      <q-td :props="props">
        {{ props.value }}
      </q-td>
    </template>
  </q-table>
</template>
