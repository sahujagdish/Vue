<template>
  <q-page class="q-pa-md">
    <q-table
      :rows="postStore.posts"
      :columns="columns"
      row-key="id"
      :loading="loading"
      title="Posts"
    />
  </q-page>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'
//import { usePostStore } from 'stores/postStore'
import { usePostStore } from '../stores/posts/postStore';
import type { QTableColumn } from 'quasar'

const { t } = useI18n()
const postStore = usePostStore()
const loading = ref(true)

import type { Post } from 'src/types'

const columns: QTableColumn<Post>[] = [
  { name: 'id', label: t('id'), field: 'id', sortable: true },
  { name: 'title', label: t('title'), field: 'title', sortable: true },
  { name: 'body', label: t('body'), field: 'body' }
]


// const getPost = () => {
//   postStore.dispatchGetPosts();
// };

onMounted( async () => {
  //await postStore.fetchPosts()
  await postStore.dispatchGetPosts();
  loading.value = false
})
</script>
