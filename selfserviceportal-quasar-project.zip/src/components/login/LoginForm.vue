<template>
  <form @submit.prevent="handleLogin" class="q-gutter-md">
    <CtlTextBox
      v-model="username"
      :label="t('login.usernamePlaceholder')"
      :error-message="errors.username"
      :is-enable="showErrors"
      size="medium"
    />
    <CtlTextBox
      v-model="password"
      :label="t('login.passwordPlaceholder')"
      :error-message="errors.password"
      :is-enable="showErrors"
      size="medium"
    />

    <!-- Centered Button -->
    <div class="row justify-center">
      <CtlButton :label="t('login.loginButton')" @click="handleLogin" />
    </div>

    <q-banner v-if="error" class="bg-red-1 text-red-9">{{ error }}</q-banner>
  </form>
</template>


<script setup lang="ts">
import { ref,reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { useLoginStore } from '../../stores/login/loginStore'

const { t } = useI18n()
const router = useRouter()
const store = useLoginStore()

const username = ref('')
const password = ref('')
const error = ref('')
const showErrors = ref(false)
const errors = reactive({
  username: '',
  password: ''
})

async function handleLogin() {
  showErrors.value = true

  errors.username = username.value
    ? username.value.length < 3
      ? t('errors.username.tooShort', { min: 3 })
      : username.value.length > 12
        ? t('errors.username.tooLong', { max: 12 })
        : /^[a-zA-Z0-9_]+$/.test(username.value)
          ? ''
          : t('errors.username.invalid')
    : t('errors.required')
    errors.password = password.value ? '' : t('errors.required')
    const hasErrors = Object.values(errors).some(e => !!e)

  if (hasErrors) {
    return;
  } else {
    const success = await store.login({ username: username.value, password: password.value })
  if (success) {
    void router.push('/home')
  } else {
    error.value = store.error
  }
    
  }
  
}

</script>
