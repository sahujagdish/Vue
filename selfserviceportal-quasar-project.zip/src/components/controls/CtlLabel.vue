<template>
  <label v-bind="{ class: ['ctl-label', alignClass], ...(forId ? { for: forId } : {}) }">
    <span>{{ text }}</span>
    <span v-if="required" class="text-red q-ml-xs">*</span>
  </label>
</template>

<script setup lang="ts">
const alignMap = {
  left: 'text-left',
  center: 'text-center',
  right: 'text-right'
} as const

const props = defineProps<{
  text: string
  forId?: string
  required?: boolean
  align?: keyof typeof alignMap
}>()

const alignClass = alignMap[props.align ?? 'left']
</script>

<style scoped>
.ctl-label {
  display: inline-block;
  font-weight: 500;
  font-size: 14px;
}
</style>
