<template>
  <div>
    <div v-for="option in props.options" :key="option">
      <q-checkbox
        :label="option"
        :model-value="props.modelValue.includes(option)"
        @update:model-value="checked => toggleOption(option, checked)"
      />
    </div>
    <q-icon v-if="props.errorMessage && props.isEnable" name="error" color="negative" />
    <div v-if="props.errorMessage && props.isEnable" class="text-negative text-caption">{{ props.errorMessage }}</div>
  </div>
</template>

<script lang="ts" setup>
const props = defineProps<{
  options: string[]
  modelValue: string[]
  errorMessage?: string
  isEnable?: boolean
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string[]): void
}>()

function toggleOption(option: string, checked: boolean) {
  const newValue = checked
    ? [...props.modelValue, option]
    : props.modelValue.filter(o => o !== option)
  emit('update:modelValue', newValue)
}
</script>
