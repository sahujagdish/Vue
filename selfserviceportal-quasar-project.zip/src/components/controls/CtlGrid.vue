<!-- <script setup lang="ts">
import { ref, computed, watch } from 'vue'
import type { GridRow, GridColumn } from 'src/types/components'

const {
  rows,
  columns,
  loading,
  rowColor,
  isEditable,
  isAction,
  rowSelection,
  pagination,
  selectionCount,
  isSearch,
  page,
  rowsPerPage
} = defineProps<{
  rows: GridRow[]
  columns: GridColumn[]
  loading: boolean
  rowColor: (row: GridRow) => string
  isEditable: 0 | 1 | 2
  isAction: 0 | 1
  rowSelection: 0 | 1
  pagination: 0 | 1
  selectionCount: 0 | 1
  isSearch: 0 | 1
  page?: number
  rowsPerPage?: number
}>()

const emit = defineEmits<{
  (e: 'edit', row: GridRow): void
  (e: 'update', row: GridRow): void
  (e: 'delete', row: GridRow): void
  (e: 'add'): void
  (e: 'bulk-delete', rows: GridRow[]): void
  (e: 'sort', col: string, desc: boolean): void
  (e: 'update:selected', rows: GridRow[]): void
  (e: 'page-change', page: number): void
  (e: 'page-size-change', size: number): void
}>()

const selected = ref<GridRow[]>([])
const sortBy = ref('')
const descending = ref(false)
const paginationState = ref({
  page: page ?? 1,
  rowsPerPage: rowsPerPage ?? 10
})
const filter = ref('')

watch(() => page, (newPage) => {
  if (newPage !== undefined) paginationState.value.page = newPage
})

watch(() => rowsPerPage, (newSize) => {
  if (newSize !== undefined) paginationState.value.rowsPerPage = newSize
})

const visibleRows = computed(() => {
  const filtered = rows.filter(row =>
    Object.values(row).some(val =>
      typeof val === 'string' || typeof val === 'number' || typeof val === 'boolean'
        ? String(val).toLowerCase().includes(filter.value.toLowerCase())
        : false
    )
  )

  const sorted = [...filtered]
  if (sortBy.value) {
    sorted.sort((a, b) => {
      const valA = a[sortBy.value]
      const valB = b[sortBy.value]

      const strA =
        typeof valA === 'string' || typeof valA === 'number' || typeof valA === 'boolean'
          ? String(valA)
          : ''
      const strB =
        typeof valB === 'string' || typeof valB === 'number' || typeof valB === 'boolean'
          ? String(valB)
          : ''

      return descending.value
        ? strB.localeCompare(strA)
        : strA.localeCompare(strB)
    })
  }

  const start = (paginationState.value.page - 1) * paginationState.value.rowsPerPage
  const end = start + paginationState.value.rowsPerPage
  return sorted.slice(start, end)
})

function toggleSort(col: string): void {
  if (sortBy.value === col) {
    descending.value = !descending.value
  } else {
    sortBy.value = col
    descending.value = false
  }
  emit('sort', col, descending.value)
}

function onSelectionChange(rows: readonly GridRow[]): void {
  selected.value = [...rows]
  emit('update:selected', [...rows])
}

function onPageChange(page: number): void {
  paginationState.value.page = page
  emit('page-change', page)
}

function onPageSizeChange(size: number): void {
  paginationState.value.rowsPerPage = size
  paginationState.value.page = 1
  emit('page-size-change', size)
}

watch(
  () => rows.length,
  () => {
    const maxPage = Math.ceil(rows.length / paginationState.value.rowsPerPage) || 1
    if (paginationState.value.page > maxPage) {
      paginationState.value.page = maxPage
    }
  }
)
</script>

<template>
  <div class="ctl-grid q-pa-md">
    <q-input
      v-if="isSearch === 0"
      v-model="filter"
      debounce="300"
      placeholder="Search..."
      outlined
      dense
      class="q-mb-sm"
    />

    <q-table
      :rows="visibleRows"
      :columns="columns"
      row-key="id"
      :selected="selected"
      :pagination="paginationState"
      :rows-per-page-options="[5, 10, 20, 50]"
      :loading="loading"
      selection="multiple"
      @update:selected="onSelectionChange"
      flat
    >
      <template v-slot:header="props">
        <q-tr :props="props">
          <q-th v-if="rowSelection === 0" auto-width>
            <q-checkbox v-model="props.selected" />
          </q-th>
          <q-th
            v-for="col in props.cols"
            :key="col.name"
            @click="toggleSort(col.name)"
            class="cursor-pointer"
          >
            {{ col.label }}
            <q-icon
              v-if="sortBy === col.name"
              :name="descending ? 'arrow_downward' : 'arrow_upward'"
              size="16px"
              class="q-ml-xs"
            />
          </q-th>
          <q-th v-if="isAction === 0" auto-width>Actions</q-th>
        </q-tr>
      </template>

      <template v-slot:body="props">
        <q-tr :props="props" :class="rowColor(props.row)">
          <q-td v-if="rowSelection === 0" auto-width>
            <q-checkbox v-model="props.selected" />
          </q-td>
          <q-td v-for="col in props.cols" :key="col.name">
            {{ props.row[col.field] }}
          </q-td>
          <q-td v-if="isAction === 0" auto-width>
            <q-btn flat icon="edit" @click="emit('edit', props.row)" :disable="isEditable === 2" />
            <q-btn flat icon="save" @click="emit('update', props.row)" :disable="isEditable === 2" />
            <q-btn flat icon="delete" @click="emit('delete', props.row)" />
          </q-td>
        </q-tr>
      </template>

      <template v-slot:bottom="scope">
        <div v-if="pagination === 0" class="row items-center justify-between q-pa-sm">
          <div class="row items-center q-gutter-sm">
            <q-select
              v-model="paginationState.rowsPerPage"
              :options="[5, 10, 20, 50]"
              dense
              outlined
              label="Rows per page"
              @update:model-value="onPageSizeChange"
              style="width: 150px"
            />
            <q-pagination
              v-model="paginationState.page"
              :max="scope.pagesNumber"
              @update:model-value="onPageChange"
              color="primary"
              size="sm"
            />
          </div>
          <div class="row items-center q-gutter-sm">
            <q-btn label="Add Row" icon="add" @click="emit('add')" color="primary" />
            <q-btn
              label="Delete Selected"
              icon="delete"
              @click="emit('bulk-delete', selected)"
              color="negative"
              :disable="selected.length === 0"
            />
          </div>
        </div>
        <div v-if="selectionCount === 0" class="text-caption q-mt-sm">
          Selected: {{ selected.length }}
        </div>
      </template>
    </q-table>
  </div>
</template> -->
<template>
  <div>CtlGrid Component</div>
</template>
