<template>
  <div>
    <q-editor
      :model-value="modelValue"
      @update:model-value="val => {
        if (typeof val === 'string') emit('update:modelValue', val)
      }"
      :definitions="definitions"
      :toolbar="toolbar"
    />
    <q-icon v-if="errorMessage && isEnable" name="error" color="negative" />
    <div v-if="errorMessage && isEnable" class="text-negative text-caption">{{ errorMessage }}</div>
  </div>
</template>

<script lang="ts" setup>
defineProps<{
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const toolbar = [
  ['bold', 'italic', 'underline'],
  ['quote', 'unordered', 'ordered'],
  ['link', 'image']
]

const definitions = {
  bold: { label: 'Bold', icon: 'format_bold' },
  italic: { label: 'Italic', icon: 'format_italic' },
  underline: { label: 'Underline', icon: 'format_underlined' }
}
</script>
