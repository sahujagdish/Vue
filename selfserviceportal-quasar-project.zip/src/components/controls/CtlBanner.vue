<template>
  <q-banner :class="bannerClass">
    <q-icon :name="iconName" />
    <span>{{ message }}</span>
  </q-banner>
</template>

<script lang="ts" setup>
import { computed } from 'vue'

const props = defineProps<{
  type: 'success' | 'error' | 'info'
  message: string
}>()

const bannerClass = computed(() => {
  return {
    'bg-green-3 text-white': props.type === 'success',
    'bg-red-3 text-white': props.type === 'error',
    'bg-blue-3 text-white': props.type === 'info'
  }
})

const iconName = computed(() => ({
  success: 'check_circle',
  error: 'error',
  info: 'info'
}[props.type]))
</script>
