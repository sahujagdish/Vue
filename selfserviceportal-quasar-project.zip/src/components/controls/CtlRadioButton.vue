<template>
  <div>
    <q-radio
      v-for="option in options"
      :key="option"
      :label="option"
      :val="option"
      :model-value="modelValue"
      @update:model-value="val => {
        if (typeof val === 'string') emit('update:modelValue', val)
      }"
    />
    <q-icon v-if="errorMessage && isEnable" name="error" color="negative" />
    <div v-if="errorMessage && isEnable" class="text-negative text-caption">{{ errorMessage }}</div>
  </div>
</template>

<script lang="ts" setup>
defineProps<{
  options: string[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()
</script>
