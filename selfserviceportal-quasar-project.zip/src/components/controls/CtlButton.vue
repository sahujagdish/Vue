<template>
  <q-btn :label="label" @click="emit('click')" color="primary" />
</template>

<script lang="ts" setup>
defineProps<{ label: string }>()

const emit = defineEmits<{ (e: 'click'): void }>()
</script>
