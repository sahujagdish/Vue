<template>
  <q-btn
    :label="label"
    :icon="icon"
    :disable="disable"
    @click="emit('click')"
    color="primary"
    class="q-ml-sm"
  />
</template>

<script lang="ts" setup>
withDefaults(defineProps<{
  label: string
  icon?: string
  disable?: boolean
}>(), {
  disable: false   // 🔧 default value
})

const emit = defineEmits<{
  (e: 'click'): void
}>()
</script>
