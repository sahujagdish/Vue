<template>
  <div>
    <q-checkbox
      :label="label"
      :model-value="modelValue"
      @update:model-value="val => {
        if (typeof val === 'boolean') emit('update:modelValue', val)
      }"
      :error="!!errorMessage && isEnable"
    />
    <q-icon v-if="errorMessage && isEnable" name="error" color="negative" />
    <div v-if="errorMessage && isEnable" class="text-negative text-caption">{{ errorMessage }}</div>
  </div>
</template>

<script lang="ts" setup>
defineProps<{
  label: string
  modelValue: boolean
  errorMessage?: string
  isEnable?: boolean
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: boolean): void
}>()
</script>
