<template>
  <div :class="sizeClass">
    <q-input
      :label="resolvedLabel"
      :model-value="displayValue"
      :error="!!computedErrorMessage && isEnable"
      :error-message="computedErrorMessage"
      readonly
      outlined
      :dense="size === 'small'"
    >
      <template #append>
        <q-icon name="event" class="cursor-pointer" @click="openCalendar" />
      </template>

      <q-popup-proxy ref="popupRef" cover transition-show="scale" transition-hide="scale">
        <q-date
          v-model="internalValue"
          :min="minDate"
          :max="maxDate"
          @update:model-value="onDateSelected"
        />
      </q-popup-proxy>
    </q-input>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { date } from 'quasar'

const { t } = useI18n()

const props = withDefaults(defineProps<{
  label: string
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
  minDate?: string
  maxDate?: string
  size?: 'small' | 'medium' | 'large'
}>(), {
  errorMessage: '',
  isEnable: false,
  size: 'medium'
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const popupRef = ref()
const internalValue = ref(props.modelValue)

watch(() => props.modelValue, val => {
  internalValue.value = val
})

function openCalendar() {
  popupRef.value?.show()
}

function onDateSelected(val: string) {
  internalValue.value = val
  emit('update:modelValue', val)
  popupRef.value?.hide()
}

const displayValue = computed(() =>
  internalValue.value ? date.formatDate(internalValue.value, 'DD MMM YYYY') : ''
)

const resolvedLabel = computed(() =>
  props.label.startsWith('labels.') ? t(props.label, props.label) : props.label
)

const computedErrorMessage = computed(() => {
  if (!props.isEnable) return ''
  return props.errorMessage.startsWith('errors.')
    ? t(props.errorMessage, props.errorMessage)
    : props.errorMessage
})

const sizeClass = computed(() => {
  switch (props.size) {
    case 'small': return 'ctl-size-small'
    case 'large': return 'ctl-size-large'
    default: return 'ctl-size-medium'
  }
})
</script>

<style scoped>
.ctl-size-small { min-width: 150px; font-size: 0.85rem; }
.ctl-size-medium { min-width: 250px; font-size: 1rem; }
.ctl-size-large { min-width: 350px; font-size: 1.15rem; }
</style>
