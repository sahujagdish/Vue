<template>
  <div class="column q-gutter-sm">
    <label class="text-bold">{{ label }}</label>

    <q-select
      :options="normalizedOptions"
      :model-value="modelValue"
      @update:model-value="emit('update:modelValue', $event)"
      :disable="!isEnable"
      outlined
      dense
      emit-value
      map-options
    >
      <!-- Tooltip -->
      <template v-if="tooltip" v-slot:append>
        <q-tooltip>{{ tooltip }}</q-tooltip>
      </template>

      <!-- Custom option rendering with icon -->
      <template v-slot:option="scope">
        <q-item v-bind="scope.itemProps">
          <q-item-section avatar v-if="scope.opt.icon">
            <q-icon :name="scope.opt.icon" />
          </q-item-section>
          <q-item-section>
            <q-item-label>{{ scope.opt.label }}</q-item-label>
          </q-item-section>
        </q-item>
      </template>
    </q-select>

    <div v-if="errorMessage" class="text-negative text-caption">
      {{ errorMessage }}
    </div>
  </div>
</template>

<script lang="ts" setup>
import { defineProps, defineEmits, computed } from 'vue'

type DropDownListOption = string | { label: string; value: string; icon?: string }

const props = defineProps<{
  label: string
  options: DropDownListOption[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
  tooltip?: string
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const normalizedOptions = computed(() =>
  props.options.map(opt =>
    typeof opt === 'string'
      ? { label: opt, value: opt }
      : {
          label: opt.label,
          value: opt.value,
          icon: opt.icon
        }
  )
)
</script>

<style scoped>
label {
  font-size: 14px;
}
</style>
  