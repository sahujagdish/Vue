<script lang="ts" setup>
import { computed, defineProps, defineEmits } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = defineProps<{
  label: string
  options: (string | { label: string; value: string })[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}>()

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const normalizedOptions = computed(() =>
  props.options.map(opt =>
    typeof opt === 'string'
      ? { label: opt, value: opt }
      : { label: t(opt.label), value: opt.value }
  )
)
</script>

<template>
  <div class="column q-gutter-sm">
    <label class="text-bold">{{ t(label) }}</label>
    <q-option-group
      :options="normalizedOptions"
      type="radio"
      :model-value="modelValue"
      @update:model-value="emit('update:modelValue', $event)"
      :disable="!isEnable"
    />
    <div v-if="errorMessage" class="text-negative text-caption">{{ errorMessage }}</div>
  </div>
</template>
