<template>
  <div :class="sizeClass">
    <q-input
      :label="resolvedLabel"
      :model-value="modelValue"
      @update:model-value="val => {
        if (val !== null) validateAndEmit(String(val))
      }"
      :error="!!computedErrorMessage && isEnable"
      :error-message="computedErrorMessage"
      outlined
      :dense="size === 'small'"
    />
  </div>
</template>

<script lang="ts" setup>
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = withDefaults(defineProps<{
  label: string
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
  minlength?: number
  regex?: string
  size?: 'small' | 'medium' | 'large'
}>(), {
  errorMessage: '',
  isEnable: false,
  minlength: 0,
  size: 'medium'
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const resolvedLabel = computed(() =>
  props.label.startsWith('labels.') ? t(props.label, props.label) : props.label
)

const computedErrorMessage = computed(() => {
  if (!props.isEnable) return ''
  const val = props.modelValue || ''

  if (val.length < props.minlength) {
    return t('errors.minlength', { min: props.minlength }, `Minimum ${props.minlength} characters required.`)
  }

  if (props.regex && props.regex.trim() !== '' && !new RegExp(props.regex).test(val)) {
    return t('errors.invalidFormat', {}, 'Input format is invalid.')
  }

  return props.errorMessage.startsWith('errors.')
    ? t(props.errorMessage, props.errorMessage)
    : props.errorMessage
})

const sizeClass = computed(() => {
  switch (props.size) {
    case 'small': return 'ctl-size-small'
    case 'large': return 'ctl-size-large'
    default: return 'ctl-size-medium'
  }
})

function validateAndEmit(val: string) {
  if (val === '') {
    emit('update:modelValue', val)
    return
  }

  const isValidLength = val.length >= props.minlength
  const isValidFormat = props.regex && props.regex.trim() !== ''
    ? new RegExp(props.regex).test(val)
    : true

  if (isValidLength && isValidFormat) {
    emit('update:modelValue', val)
  }
}
</script>

<style scoped>
.ctl-size-small { min-width: 150px; font-size: 0.85rem; }
.ctl-size-medium { min-width: 250px; font-size: 1rem; }
.ctl-size-large { min-width: 350px; font-size: 1.15rem; }
</style>
