<template>
  <div :class="sizeClass">
    <q-input
      :model-value="modelValue"
      @update:model-value="val => {
        if (val !== null) validateAndEmit(val)
      }"
      :error="!!computedErrorMessage && isEnable"
      :error-message="computedErrorMessage"
      outlined
      :dense="size === 'small'"
      label-slot
    >
      <!-- Custom label slot -->
      <template v-slot:label>
        {{ resolvedLabel }}
        <span v-if="mandatory" class="mandatory-asterisk">*</span>
      </template>
    </q-input>
  </div>
</template>

<script lang="ts" setup generic="T extends string | number | FileList | null | undefined">
import { computed } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()

const props = withDefaults(defineProps<{
  label: string
  modelValue: T
  errorMessage?: string
  isEnable?: boolean
  minlength?: number
  regex?: string
  size?: 'small' | 'medium' | 'large'
  mandatory?: boolean
}>(), {
  errorMessage: '',
  isEnable: false,
  minlength: 0,
  size: 'medium',
  mandatory: false
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: T): void
}>()

const resolvedLabel = computed(() =>
  props.label.startsWith('labels.') ? t(props.label, props.label) : props.label
)

const computedErrorMessage = computed(() => {
  if (!props.isEnable) return ''

  const val = props.modelValue
  const strVal =
    typeof val === 'string'
      ? val
      : typeof val === 'number'
        ? String(val)
        : ''

  if (props.mandatory && strVal.trim() === '') {
    return props.errorMessage?.trim()
      ? (props.errorMessage.startsWith('errors.')
          ? t(props.errorMessage, props.errorMessage)
          : props.errorMessage)
      : `${resolvedLabel.value} is required.`
  }

  if (strVal.length < props.minlength) {
    return t('errors.minlength', { min: props.minlength }, `Minimum ${props.minlength} characters required.`)
  }

  if (props.regex && props.regex.trim() !== '' && !new RegExp(props.regex).test(strVal)) {
    return t('errors.invalidFormat', {}, 'Input format is invalid.')
  }

  return props.errorMessage.startsWith('errors.')
    ? t(props.errorMessage, props.errorMessage)
    : props.errorMessage
})

const sizeClass = computed(() => {
  switch (props.size) {
    case 'small': return 'ctl-size-small'
    case 'large': return 'ctl-size-large'
    default: return 'ctl-size-medium'
  }
})

function validateAndEmit(val: string | number | FileList) {
  const strVal =
    typeof val === 'string'
      ? val
      : typeof val === 'number'
        ? String(val)
        : ''

  if (strVal === '') {
    emit('update:modelValue', val as T)
    return
  }

  const isValidLength = strVal.length >= props.minlength
  const isValidFormat = props.regex && props.regex.trim() !== ''
    ? new RegExp(props.regex).test(strVal)
    : true

  if (isValidLength && isValidFormat) {
    emit('update:modelValue', val as T)
  }
}
</script>

<style scoped>
.ctl-size-small { min-width: 150px; font-size: 0.85rem; }
.ctl-size-medium { min-width: 250px; font-size: 1rem; }
.ctl-size-large { min-width: 350px; font-size: 1.15rem; }

.mandatory-asterisk {
  color: red;
  margin-left: 2px;
}
</style>
