<template>
  <q-breadcrumbs class="q-pa-sm">
    <q-breadcrumbs-el
      v-for="(crumb, index) in breadcrumbs"
      :key="index"
      :label="$t(crumb.label)"
      :to="crumb.to"
      clickable
    />
  </q-breadcrumbs>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()

const breadcrumbs = computed(() => {
  const pathParts = route.path.split('/').filter(Boolean)
  const crumbs = pathParts.map((part, index) => {
    const to = '/' + pathParts.slice(0, index + 1).join('/')
    return { label: part || 'home', to }
  })
  return [{ label: 'home', to: '/' }, ...crumbs]
})
</script>
