<template >
  <q-header elevated class="bg-primary text-white">
    <q-toolbar-title>{{ $t('selfserviceportal') }}</q-toolbar-title>
  </q-header>
</template>
    
