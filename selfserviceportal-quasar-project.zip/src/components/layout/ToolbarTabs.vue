<template>
  <q-layout view="hHh lpR fFf">
    <!-- Horizontal Navbar -->
    <q-toolbar class="toolbar text-white bg-primary" style="height: 100px;">
      <div class="row items-center q-gutter-md">
        <q-btn-dropdown
          v-for="parent in menuItems"
          :key="parent.label"
          :label="parent.label"
          :icon="parent.icon"
          color="primary"
          flat
          dense
          dropdown-icon="arrow_drop_down"
          :class="{ 'active-parent': isActiveParent(parent) }"
        >
          <q-list>
            <!-- Parent main route -->
            <q-item clickable v-ripple @click="setBreadcrumb(parent)">
              <q-item-section>{{ parent.label }} Main</q-item-section>
            </q-item>

            <!-- Children -->
            <q-item
              v-for="child in parent.children"
              :key="child.label"
              clickable
              v-ripple
              @click="setBreadcrumb(parent, child)"
              :class="{ 'active-child': isActiveChild(child) }"
            >
              <q-item-section avatar>
                <q-icon :name="child.icon" />
              </q-item-section>
              <q-item-section>{{ child.label }}</q-item-section>
            </q-item>
          </q-list>
        </q-btn-dropdown>
      </div>
    </q-toolbar>

    <!-- Breadcrumbs -->
    <q-toolbar class="bg-grey-2 text-primary">
      <q-breadcrumbs>
        <q-breadcrumbs-el
          v-for="crumb in breadcrumbs"
          :key="crumb.route"
          :label="crumb.label"
          :to="crumb.route"
        />
      </q-breadcrumbs>
    </q-toolbar>

    <!-- Page container -->
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()

interface ChildItem {
  label: string
  icon: string
  route: string
}
interface MenuItem {
  label: string
  icon: string
  route: string
  children: ChildItem[]
}
interface BreadcrumbItem {
  label: string
  route: string
}

const menuItems: MenuItem[] = [
  {
    label: 'Home',
    icon: 'dashboard',
    route: '/',
    children: [
      { label: 'home', icon: 'bar_chart', route: '/home' },
      { label: 'DQ', icon: 'analytics', route: '/dqi' },
      { label: 'DQICommercial', icon: 'analytics', route: '/dqicommercial' }
    ]
  },
  {
    label: 'consumer',
    icon: 'settings',
    route: '/consumer',
    children: [
      { label: 'sample', icon: 'person', route: '/consumer/sample' },
      { label: 'posts', icon: 'lock', route: '/consumer/posts' }
    ]
  }
]

// Breadcrumb state
const breadcrumbs = ref<BreadcrumbItem[]>([])

function navigate(path: string) {
  void router.push(path)
}

// Set breadcrumbs when navigating
function setBreadcrumb(parent: MenuItem, child?: ChildItem) {
  const crumbs: BreadcrumbItem[] = []
  crumbs.push({ label: parent.label, route: parent.route })
  if (child) {
    crumbs.push({ label: child.label, route: child.route })
    navigate(child.route)
  } else {
    navigate(parent.route)
  }
  breadcrumbs.value = crumbs
}

// Active highlighting
function isActiveParent(parent: MenuItem): boolean {
  if (route.path === parent.route) return true
  return parent.children.some(child => route.path === child.route)
}
function isActiveChild(child: ChildItem): boolean {
  return route.path === child.route
}
</script>

<style scoped>
.active-parent {
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 4px;
}
.active-child {
  background-color: rgba(0, 0, 0, 0.1);
}
</style>

<!-- <script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const tab = ref('home') 

const tabs = [
  { name: 'home', label: 'home', route: '/' },
  { name: 'posts', label: 'posts', route: '/posts' },
  { name: 'sample', label: 'sample', route: '/sample' },
  { name: 'dqi', label: 'dqi', route: '/dqi' }
  
]

function navigate(route: string) {
  router.push(route).catch(() => {})
}
</script>
-->
<style lang="scss" scoped>
.q-toolbar {
background-color: $toolbar;
  border-bottom: 1px solid white;
}
</style> 
