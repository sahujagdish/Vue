<template>
  <q-toolbar class="toolbar text-white">
    <q-tabs
      v-model="tab"
      inline-label
      shrink
      class="text-white"
      active-color="yellow"
      indicator-color="white"
    >
      <q-tab
        v-for="item in tabs"
        :key="item.name"
        :name="item.name"
        :label="$t(item.label)"
        @click="navigate(item.route)"
      />
    </q-tabs>
  </q-toolbar>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const tab = ref('home') 

const tabs = [
  { name: 'home', label: 'home', route: '/' },
  { name: 'posts', label: 'posts', route: '/posts' },
  { name: 'sample', label: 'sample', route: '/sample' },
  { name: 'dqi', label: 'dqi', route: '/dqi' }
  
]

function navigate(route: string) {
  router.push(route).catch(() => {})
}
</script>

<style lang="scss" scoped>
.q-toolbar {
background-color: $toolbar;
  border-bottom: 1px solid white;
}
</style>
