<template>
  <div class="q-pa-md q-gutter-sm">
    <q-select
      filled
      v-model="selectedLocale"
      :options="localeOptions"
      @update:model-value="changeLocale"
      label="Language"
    />
    <q-btn
      :label="themeLabel"
      color="primary"
      @click="toggleTheme"
      icon="brightness_6"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'

const { locale } = useI18n()

const selectedLocale = ref(localStorage.getItem('locale') || 'en')

const localeOptions = [
  { label: 'English', value: 'en' },
  { label: 'हिन्दी', value: 'hi' },
  { label: 'Português', value: 'pt' },
  { label: 'Français', value: 'fr' }
]

function changeLocale(newLocale: { label: string; value: string }) {
  locale.value = newLocale.value;
  localStorage.setItem('locale', newLocale.value);
}

const themeLabel = computed(() => {
  const current = document.documentElement.getAttribute('data-theme') || 'light'
  return current === 'dark' ? 'Switch to Light Theme' : 'Switch to Dark Theme'
})

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light'
  const next = current === 'dark' ? 'light' : 'dark'
  document.documentElement.setAttribute('data-theme', next)
  localStorage.setItem('theme', next)
}
</script>

<style scoped>
.q-select,
.q-btn {
  width: 250px;
}
</style>
