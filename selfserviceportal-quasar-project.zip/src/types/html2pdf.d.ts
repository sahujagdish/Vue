// html2pdf.d.ts
// Strictly typed declarations for html2pdf.js chaining API.
// Place this file in src/types or src, and ensure "typeRoots" includes it if needed.

declare module 'html2pdf.js' {
    /**
     * Core options accepted by html2pdf.js.
     */
    export interface Html2PdfOptions {
        // Layout
        margin?: number | [number, number] | [number, number, number, number];
        pagebreak?: {
            mode?: 'avoid' | 'css' | 'legacy' | string[];
            before?: string | string[];
        };

        // File metadata
        filename?: string;
        image?: {
            type?: 'jpeg' | 'png' | 'webp';
            quality?: number; // 0..1
        };

        // Canvas rendering
        html2canvas?: Partial<Html2CanvasOptions>;
        // PDF generation
        jsPDF?: Partial<JsPdfOptions>;
    }

    /**
     * Subset of html2canvas options commonly used with html2pdf.js.
     */
    export interface Html2CanvasOptions {
        scale?: number;
        useCORS?: boolean;
        scrollX?: number;
        scrollY?: number;
    }

    /**
     * Subset of jsPDF init options commonly used with html2pdf.js.
     */
    export interface JsPdfOptions {
        unit?: 'pt' | 'mm' | 'cm' | 'in';
        format?:
        | 'a0' | 'a1' | 'a2' | 'a3' | 'a4' | 'a5'
        | 'letter' | 'legal' | 'tabloid'
        | [number, number];
        orientation?: 'portrait' | 'landscape';
    }

    /**
     * Instance chain returned by html2pdf().
     */
    export interface Html2PdfInstance {
        set: (options: Html2PdfOptions) => Html2PdfInstance;
        from: (source: HTMLElement | string) => Html2PdfInstance;
        toPdf: () => Html2PdfInstance;
        save: (filename?: string) => Promise<void>;
        outputPdf: (
            type?:
                | 'arraybuffer'
                | 'blob'
                | 'bloburi'
                | 'datauristring'
                | 'dataurlstring'
                | 'dataurl'
                | 'binarystring'
                | 'uint8array',
        ) => Promise<string | ArrayBuffer | Blob | Uint8Array>;
        get: (key: 'jsPDF' | 'pdf') => Promise<unknown>;
        then: (onFulfilled: (jsPdfInstance: unknown) => void) => Html2PdfInstance;
        catch: (onRejected: (error: unknown) => void) => Html2PdfInstance;
    }

    /**
     * Factory function. Starts a new chain.
     */
    export default function html2pdf(): Html2PdfInstance;
}
