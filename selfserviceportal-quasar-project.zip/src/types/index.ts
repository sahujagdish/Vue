export interface FormData {
  id: string
  name: string
  age: number
  gender: 'male' | 'female'
}

export interface Post {
  userId: number
  id: number
  title: string
  body: string
}
