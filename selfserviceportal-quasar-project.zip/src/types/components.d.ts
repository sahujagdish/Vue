import type { DefineComponent } from 'vue'

type TableColumn = {
  name: string
  label: string
  align: 'left' | 'center' | 'right'
  field: string
  sortable?: boolean
}

type TableRow = {
  [key: string]: string | number | boolean | null
}

type DropDownListOption = string | { label: string; value: string; icon?: string }

type TextBoxProps = {
  label: string
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
  minLength?: number
  size?: 'small' | 'medium' | 'large'
  regex?: string
}

type DropDownListProps = {
  label: string
  options: DropDownListOption[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
  tooltip?: string
}

type CheckBoxProps = {
  label: string
  modelValue: boolean
  errorMessage?: string
  isEnable?: boolean
}

type GroupCheckBoxProps = {
  label: string
  options: string[]
  modelValue: string[]
  errorMessage?: string
  isEnable?: boolean
}

type RadioButtonProps = {
  label: string
  options: string[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

type GroupRadioOption = string | { label: string; value: string }

type GroupRadioButtonProps = {
  label: string
  options: GroupRadioOption[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

type RichTextBoxProps = {
  label: string
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

type ButtonProps = {
  label: string
}

type BannerProps = {
  type: 'success' | 'error' | 'info'
  message: string
}

type DateProps = {
  label: string
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

type TableProps = {
  title?: string
  columns: TableColumn[]
  rows: TableRow[]
}

declare module 'vue' {
  export interface GlobalComponents {
    CtlTextBox: DefineComponent<TextBoxProps>
    CtlDropDownList: DefineComponent<DropDownListProps>
    CtlCheckBox: DefineComponent<CheckBoxProps>
    CtlGroupCheckBox: DefineComponent<GroupCheckBoxProps>
    CtlRadioButton: DefineComponent<RadioButtonProps>
    CtlGroupRadioButton: DefineComponent<GroupRadioButtonProps>
    CtlRichTextBox: DefineComponent<RichTextBoxProps>
    CtlButton: DefineComponent<ButtonProps>
    CtlBanner: DefineComponent<BannerProps>
    CtlDate: DefineComponent<DateProps>
    CtlTable: DefineComponent<TableProps>
    CtlMarkupTable: DefineComponent<TableProps>
  }
}
