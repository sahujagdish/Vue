import type { DefineComponent } from 'vue'

type TableColumn = {
  name: string
  label: string
  align: 'left' | 'center' | 'right'
  field: string
  sortable?: boolean
}

type TableRow = {
  [key: string]: string | number | boolean | null
}

type DropDownListOption = string | { label: string; value: string; icon?: string }

type LabelProps = {
  text: string
  forId?: string
  required?: boolean
  align?: 'left' | 'center' | 'right'
}

type TextBoxProps<T extends string | number | FileList | null | undefined = string> = {
  label: string
  modelValue: T
  errorMessage?: string
  isEnable?: boolean
  minlength?: number
  size?: 'small' | 'medium' | 'large'
  regex?: string,
  mandatory?: boolean
}

type DropDownListProps = {
  label: string
  options: DropDownListOption[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
  tooltip?: string
}

type CheckBoxProps = {
  label: string
  modelValue: boolean
  errorMessage?: string
  isEnable?: boolean
}

type GroupCheckBoxProps = {
  label: string
  options: string[]
  modelValue: string[]
  errorMessage?: string
  isEnable?: boolean
}

type RadioButtonProps = {
  label: string
  options: string[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

type GroupRadioOption = string | { label: string; value: string }

type GroupRadioButtonProps = {
  label: string
  options: GroupRadioOption[]
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

type RichTextBoxProps = {
  label: string
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

type ButtonProps = {
  label?: string
  icon?: string
  disable?: boolean
}

type BannerProps = {
  type: 'success' | 'error' | 'info'
  message: string
}

type DateProps = {
  label: string
  modelValue: string
  errorMessage?: string
  isEnable?: boolean
}

// export interface GridRow {
//   id: string | number
//   name?: string
//   role?: string
//   [key: string]: unknown
// }

// export interface GridColumn {
//   name: string
//   label: string
//   field: string
//   align?: 'left' | 'right' | 'center'
//   sortable?: boolean
//   format?: (val: unknown, row: GridRow) => string
// }

// export type GridProps = {
//   rows: GridRow[]
//   columns: GridColumn[]
//   loading?: boolean
//   rowColor?: (row: GridRow) => string

//   // Display and behavior flags
//   isEditable?: 0 | 1 | 2           // 0: inline, 1: popup, 2: disabled
//   selectionAll?: 0 | 1             // 0: show select all, 1: hide
//   isAction?: 0 | 1                 // 0: show action buttons, 1: hide
//   rowSelection?: 0 | 1             // 0: show row checkboxes, 1: hide
//   pagination?: 0 | 1               // 0: show pagination, 1: hide
//   selectionCount?: 0 | 1           // 0: show count, 1: hide
//   isSearch?: 0 | 1                 // 0: show search, 1: hide

//   page?: number
//   rowsPerPage?: number
// }

declare module 'vue' {
  export interface GlobalComponents {
    CtlTextBox: DefineComponent<TextBoxProps<string | number | FileList | null | undefined>>
    CtlDropDownList: DefineComponent<DropDownListProps>
    CtlCheckBox: DefineComponent<CheckBoxProps>
    CtlGroupCheckBox: DefineComponent<GroupCheckBoxProps>
    CtlRadioButton: DefineComponent<RadioButtonProps>
    CtlGroupRadioButton: DefineComponent<GroupRadioButtonProps>
    CtlRichTextBox: DefineComponent<RichTextBoxProps>
    CtlButton: DefineComponent<ButtonProps>
    CtlBanner: DefineComponent<BannerProps>
    CtlDate: DefineComponent<DateProps>
    CtlLabel: DefineComponent<LabelProps>
    CtlGrid: DefineComponent<GridProps>
  }
}


