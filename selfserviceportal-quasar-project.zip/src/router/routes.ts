import type { RouteRecordRaw } from 'vue-router';
import type { NavigationGuardNext, RouteLocationNormalized } from 'vue-router'
import { useLoginStore } from '../stores/login/loginStore'

export function authGuard(
  to: RouteLocationNormalized,
  _from: RouteLocationNormalized, // prefixed with underscore to silence unused warning
  next: NavigationGuardNext
) {
  const store = useLoginStore()
  const requiredRole = to.meta.role as string | undefined

  if (!store.isAuthenticated) {
    next('/login')
  } else if (requiredRole && store.user?.role !== requiredRole) {
    next('/unauthorized')
  } else {
    next()
  }
}

const routes: RouteRecordRaw[] = [

  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [

      { path: '', component: () => import('pages/HomePage.vue') },
      { path: 'home', component: () => import('pages/HomePage.vue') },
      { path: 'posts', component: () => import('pages/PostPage.vue') },
      { path: 'sample', component: () => import('pages/SamplePage.vue') },
      { path: 'dqi', component: () => import('pages/DqiReport.vue') }
    ],
    beforeEnter: authGuard,
    meta: { role: 'user' }
  },
  {
    path: '/login',
    component: () => import('pages/LoginPage.vue')
  },
  {
    path: '/unauthorized',
    component: () => import('../pages/UnauthorizedPage.vue')
  },
  // Always leave this as last one,
  // but you can also remove it
  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue'),
  },
];

export default routes;

