// services/dqi/types.ts
export interface DqiReportDTO {
    nameWeighted: string
    nameActual: string
    dobWeighted: string
    dobActual: string
    panWeighted: string
    panActual: string
    pincodeWeighted: string
    pincodeActual: string
    phoneWeighted: string
    phoneActual: string
    dpdWeighted: string
    dpdActual: string
    sanctionWeighted: string
    sanctionActual: string
    openedWeighted: string
    openedActual: string
    balanceWeighted: string
    balanceActual: string
    accountTypeWeighted: string
    accountTypeActual: string
    score: string
}

export interface DqiParams {
    reportView: string
    cycle: string
    portfolio: string
    fileName: string
}
