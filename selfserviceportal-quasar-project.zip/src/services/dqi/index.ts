// services/dqi/index.ts
import axios from 'axios'
import type { DqiParams, DqiReportDTO } from './types'

const getReport = (params: DqiParams) =>
    axios.get<DqiReportDTO>('/api/dqi-report', { params })

export const dqiService = {
    getReport
};