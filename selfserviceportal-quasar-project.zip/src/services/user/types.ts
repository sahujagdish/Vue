// // src/types/index.ts
// export interface GridRow {
//     id: string | number
//     name: string
//     role: string
//     [key: string]: unknown
// }

// export interface GridColumn {
//     name: string
//     label: string
//     field: string
//     align?: 'left' | 'right' | 'center'
//     sortable?: boolean
//     format?: (val: unknown, row: GridRow) => string
// }
