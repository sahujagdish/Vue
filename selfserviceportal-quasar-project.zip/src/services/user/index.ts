// // src/services/index.ts
// //import type { GridRow } from './types'
// import { axiosInstance } from '../api'
// import type { GridRow } from 'src/types/components'

// export async function fetchUsers1(): Promise<GridRow[]> {
//     return Promise.resolve([
//         { id: 1, name: 'Alice', role: 'Admin' },
//         { id: 2, name: 'Bob', role: 'User' },
//         { id: 3, name: 'Charlie', role: 'Guest' },
//         { id: 4, name: 'Diana', role: 'User' },
//         { id: 5, name: 'Eve', role: 'Admin' }
//     ])
// }

// export async function fetchUsers(): Promise<GridRow[]> {
//     try {
//         const response = await axiosInstance.get('/users')
//         return response.data as GridRow[]
//     } catch (error) {
//         console.error('Fetch users failed:', error)
//         return []
//     }
// }

// export async function addUser(user: GridRow): Promise<GridRow> {
//     try {
//         const response = await axiosInstance.post('/users', user)
//         return response.data as GridRow
//     } catch (error) {
//         console.error('Add user failed:', error)
//         throw error
//     }
// }

// export async function updateUser(user: GridRow): Promise<GridRow> {
//     try {
//         const response = await axiosInstance.put(`/users/${user.id}`, user)
//         return response.data as GridRow
//     } catch (error) {
//         console.error('Update user failed:', error)
//         throw error
//     }
// }

// export async function deleteUser(id: string | number): Promise<void> {
//     try {
//         await axiosInstance.delete(`/users/${id}`)
//     } catch (error) {
//         console.error('Delete user failed:', error)
//         throw error
//     }
// }

// export async function bulkDelete(ids: (string | number)[]): Promise<void> {
//     try {
//         await axiosInstance.post('/users/bulk-delete', { ids })
//     } catch (error) {
//         console.error('Bulk delete failed:', error)
//         throw error
//     }
// }

