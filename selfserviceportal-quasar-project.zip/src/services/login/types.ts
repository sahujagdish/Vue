export interface LoginPayload {
    username: string
    password: string
}

export interface LoginResponse {
    success: boolean
    user?: {
        username: string
        role: string
    }
    message?: string
}
