import { axiosInstance } from '../api'
import type { LoginPayload, LoginResponse } from './types'

export async function authenticate1(payload: LoginPayload): Promise<LoginResponse> {
    try {
        const response = await axiosInstance.post('/login', payload)
        return response.data
    } catch {
        return { success: false, message: 'Login failed' }
    }
}

export async function authenticate(payload: LoginPayload): Promise<LoginResponse> {
    await new Promise(resolve => setTimeout(resolve, 500)) // simulate 500ms delay
    return {
        success: true,
        user: {
            username: payload.username,
            role: 'user'
        },
        message: 'Login successful (mock)'
    }
}