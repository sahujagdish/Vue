import { PostService } from './posts';
import { dqiService } from './dqi';

export const API = {
  posts: PostService,
  dqi: dqiService
};
