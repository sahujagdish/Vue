import { boot } from 'quasar/wrappers'

export default boot(() => {
  const theme = localStorage.getItem('theme') || 'light'
  document.documentElement.setAttribute('data-theme', theme)
})
