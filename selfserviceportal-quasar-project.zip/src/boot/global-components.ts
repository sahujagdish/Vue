import { boot } from 'quasar/wrappers'
import type { App } from 'vue'

// Import your components
import CtlTextBox from '../components/controls/CtlTextBox.vue'
import CtlDropDownList from '../components/controls/CtlDropDownList.vue'
import CtlCheckBox from '../components/controls/CtlCheckBox.vue'
import CtlGroupCheckBox from '../components/controls/CtlGroupCheckBox.vue'
import CtlRadioButton from '../components/controls/CtlRadioButton.vue'
import CtlGroupRadioButton from '../components/controls/CtlGroupRadioButton.vue'
import CtlRichTextBox from '../components/controls/CtlRichTextBox.vue'
import CtlButton from '../../src/components/controls/CtlButton.vue'
import CtlBanner from '../components/controls/CtlBanner.vue'
import CtlDate from '../components/controls/CtlDate.vue'

export default boot(({ app }: { app: App }) => {
  app.component('CtlTextBox', CtlTextBox)
  app.component('CtlDropDownList', CtlDropDownList)
  app.component('CtlCheckBox', CtlCheckBox)
  app.component('CtlGroupCheckBox', CtlGroupCheckBox)
  app.component('CtlRadioButton', CtlRadioButton)
  app.component('CtlGroupRadioButton', CtlGroupRadioButton)
  app.component('CtlRichTextBox', CtlRichTextBox)
  app.component('CtlButton', CtlButton)
  app.component('CtlBanner', CtlBanner)
  app.component('CtlDate', CtlDate)
})
