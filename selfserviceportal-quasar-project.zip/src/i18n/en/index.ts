// import home from './home'
// import posts from './posts'
// import layout from './layout'

// import sample from './sample.json'

// export default {
//   labels: {
//     ...sample.labels
//   },
//   errors: {
//     ...sample.errors
//   }
// }

export default {
  labels: {
    name: "Name",
    username: "Username",
    birthdate: "Birthdate",
    favoriteFruit: "Favorite Fruit",
    acceptTerms: "Accept Terms",
    frameworks: "Frameworks",
    gender: "Gender",
    preferredTime: "Preferred Time",
    bio: "Bio",
    submit: "Submit",
    successMessage: "Form submitted successfully!"
  },
  errors: {
    required: "This field is required.",
    username: {
      tooShort: "Username must be at least {min} characters.",
      tooLong: "Username must be at most {max} characters.",
      invalid: "Username format is invalid."
    },
    birthdate: "Birthdate is required.",
    fruit: "Please select a fruit.",
    terms: "You must accept the terms.",
    frameworks: "Select at least one framework.",
    gender: "Please select a gender.",
    time: "Select a preferred time.",
    bio: "Bio cannot be empty.",
    formBanner: "Please fix the errors above.",
    minlength: "Minimum {min} characters required.",
    invalidFormat: "Input format is invalid."
  },
  dqi: {
    labels: {
      reportTitle: "Regulatory Data Quality Index Report Consumer",
      reportView: "Report View",
      consolidated: "Consolidated",
      portfolio: "Portfolio",
      cycle: "Consolidated Cycle",
      portfolioLabel: "Portfolio",
      fileName: "File Name",
      getData: "Get Data",
      tableTitle: "DQI Report Table",
      category: "Category",
      weight: "Weights",
      weightedPercentage: "Weighted Percentage",
      actualPercentage: "Actual Percentage",
      scoreLabel: "Regulatory Data Quality Index",
      segmentA: "Demographic Segment Validation (A)",
      segmentB: "Trade Segment Validations (B)",
      fields: {
        name: "Name",
        dob: "DOB",
        pan: "PAN",
        voterId: "Voter ID",
        uid: "UID",
        pincode: "PINCODE",
        phone: "Phone",
        dpd: "DPD / Asset Classification",
        sanction: "High Credit / Sanctioned amount",
        opened: "Date Opened",
        balance: "Balance Amount",
        accountType: "Account type (1- % others)"
      },
      showSummary: "Show Summary",
      hideSummary: "Hide Summary",
      summaryTitle: "DQI Report Summary"
    }
  },
  login: {
    title: 'Login',
    loginButton: 'Login',
    usernamePlaceholder: 'Username',
    passwordPlaceholder: 'Password',
    invalidCredentials: 'Invalid username or password',
    required: 'This field is required',
    welcomeMessage: 'Welcome back!',
    logoutButton: 'Logout'
  }


}