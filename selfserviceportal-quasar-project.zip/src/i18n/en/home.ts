export default {
  id: "ID",
  name: "Name",
  age: "Age",
  gender: "Gender",
  male: "Male",
  female: "Female",
  submit: "Submit",
  title: "Title",
  body: "Body",
  validation: {
    required: "This field is required",
    age: "Age must be a number"
  }
  
}
