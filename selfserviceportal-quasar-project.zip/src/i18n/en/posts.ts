export default {
posts: "Posts"
}