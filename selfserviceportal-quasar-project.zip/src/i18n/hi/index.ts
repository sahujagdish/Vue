
// import sample from './sample.json'

// export default {
//   labels: {
//     ...sample.labels
//   },
//   errors: {
//     ...sample.errors
//   }
// }


export default {
  id: "hi-ID",
  name: "hi-Name",
  age: "hi-Age",
  gender: "hi-Gender",
  male: "hi-Male",
  female: "hi-Female",
  submit: "Submit",
  title: "hi-Title",
  body: "hi-Body",
  validation: {
    required: "This field is required",
    age: "Age must be a number"
  },
  selfserviceportal: "Self Service Portal",
  home: "Home",
  settings: "Settings",
  language: "Language",
  theme: "Theme",
  switchTheme: "Switch Theme",
  switchToDark: "Switch to Dark Theme",
  switchToLight: "Switch to Light Theme",
  posts: "Posts",
  labels: {
    name: "नाम",
    username: "उपयोगकर्ता नाम",
    birthdate: "जन्म तिथि",
    favoriteFruit: "पसंदीदा फल",
    acceptTerms: "नियमों को स्वीकार करें",
    frameworks: "फ्रेमवर्क",
    gender: "लिंग",
    preferredTime: "पसंदीदा समय",
    bio: "जीवनी",
    submit: "जमा करें",
    successMessage: "फॉर्म सफलतापूर्वक सबमिट किया गया!"
  },
  errors: {
    required: "यह फ़ील्ड आवश्यक है।",
    username: {
      tooShort: "उपयोगकर्ता नाम कम से कम {min} अक्षरों का होना चाहिए।",
      tooLong: "उपयोगकर्ता नाम अधिकतम {max} अक्षरों का हो सकता है।",
      invalid: "उपयोगकर्ता नाम का प्रारूप अमान्य है।"
    },
    birthdate: "जन्म तिथि आवश्यक है।",
    fruit: "कृपया एक फल चुनें।",
    terms: "आपको नियमों को स्वीकार करना होगा।",
    frameworks: "कम से कम एक फ्रेमवर्क चुनें।",
    gender: "कृपया एक लिंग चुनें।",
    time: "कृपया एक पसंदीदा समय चुनें।",
    bio: "जीवनी खाली नहीं हो सकती।",
    formBanner: "कृपया ऊपर दी गई त्रुटियों को ठीक करें।",
    minlength: "कम से कम {min} अक्षर आवश्यक हैं।",
    invalidFormat: "इनपुट प्रारूप अमान्य है।"
  },
  dqi: {
    labels: {
      reportTitle: "नियामक डेटा गुणवत्ता सूचकांक रिपोर्ट - उपभोक्ता",
      reportView: "रिपोर्ट दृश्य",
      consolidated: "संविलित",
      portfolio: "पोर्टफोलियो",
      cycle: "संविलित चक्र",
      portfolioLabel: "पोर्टफोलियो",
      fileName: "फ़ाइल नाम",
      getData: "डेटा प्राप्त करें",
      tableTitle: "डीक्यूआई रिपोर्ट तालिका",
      category: "श्रेणी",
      weight: "वजन",
      weightedPercentage: "भारित प्रतिशत",
      actualPercentage: "वास्तविक प्रतिशत",
      scoreLabel: "नियामक डेटा गुणवत्ता सूचकांक",
      segmentA: "जनसांख्यिकीय खंड सत्यापन (A)",
      segmentB: "व्यापार खंड सत्यापन (B)",
      fields: {
        name: "नाम",
        dob: "जन्म तिथि",
        pan: "पैन",
        voterId: "मतदाता पहचान पत्र",
        uid: "यूआईडी",
        pincode: "पिनकोड",
        phone: "फ़ोन",
        dpd: "डीपीडी / संपत्ति वर्गीकरण",
        sanction: "उच्च क्रेडिट / स्वीकृत राशि",
        opened: "खाता खोलने की तिथि",
        balance: "शेष राशि",
        accountType: "खाता प्रकार (1 - % अन्य)"
      },
      showSummary: "सारांश दिखाएं",
      hideSummary: "सारांश छिपाएं",
      summaryTitle: "डीक्यूआई रिपोर्ट सारांश"
    }
  },
  login: {
    title: 'लॉगिन',
    loginButton: 'लॉगिन करें',
    usernamePlaceholder: 'उपयोगकर्ता नाम',
    passwordPlaceholder: 'पासवर्ड',
    invalidCredentials: 'अमान्य उपयोगकर्ता नाम या पासवर्ड',
    required: 'यह फ़ील्ड आवश्यक है',
    welcomeMessage: 'फिर से स्वागत है!',
    logoutButton: 'लॉगआउट'
  }



}
