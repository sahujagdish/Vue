export default {
  commercialdqi: {
    label: {
      title: 'नियामक डेटा गुणवत्ता सूचकांक - वाणिज्यिक',
      member: 'सदस्य',
      cycle: 'चक्र',
      totalBorrowers: 'कुल उधारकर्ता',
      totalCreditFacility: 'कुल क्रेडिट सुविधा',
      fileName: 'फ़ाइल नाम',
      portfolio: 'पोर्टफोलियो',
      submit: 'जमा करें',
      submitted: 'जमा किया गया',
      exportOptions: 'निर्यात विकल्प',
      exporting: 'निर्यात हो रहा है...',
      notes: 'नोट्स',
      disclaimer: 'अस्वीकरण',
      notesText: 'पते की न्यूनतम लंबाई: 5 अक्षर; अवांछित मान स्वीकार्य नहीं...',
      disclaimerText: 'सभी जानकारी सदस्य द्वारा प्रदान किए गए डेटा पर आधारित है...',
      selectExportOption: 'कृपया एक निर्यात विकल्प चुनें',
      dqi: 'डीक्यूआई स्कोर'
    },
    errors: {
      successMessage: 'सफलतापूर्वक पूर्ण हुआ',
      exportFailed: 'निर्यात विफल',
      exportSuccess: 'निर्यात सफलतापूर्वक पूर्ण हुआ'
    },
    tableHeaders: {
      category: 'श्रेणी',
      weight: 'वजन',
      actual: 'वास्तविक %',
      score: 'स्कोर',
      invalid: 'अमान्य'
    }
  },
  submit: 'जमा करें',
  labels: {
    name: "नाम",
    username: "उपयोगकर्ता नाम",
    birthdate: "जन्मतिथि",
    favoriteFruit: "पसंदीदा फल",
    acceptTerms: "नियम स्वीकार करें",
    frameworks: "फ्रेमवर्क्स",
    gender: "लिंग",
    preferredTime: "पसंदीदा समय",
    bio: "जीवनी",
    submit: "जमा करें",
    successMessage: "फॉर्म सफलतापूर्वक जमा किया गया!"
  },
  errors: {
    required: "यह फ़ील्ड आवश्यक है।",
    username: {
      tooShort: "उपयोगकर्ता नाम कम से कम {min} अक्षरों का होना चाहिए।",
      tooLong: "उपयोगकर्ता नाम अधिकतम {max} अक्षरों का होना चाहिए।",
      invalid: "उपयोगकर्ता नाम का प्रारूप अमान्य है।"
    },
    birthdate: "जन्मतिथि आवश्यक है।",
    fruit: "कृपया एक फल चुनें।",
    terms: "आपको नियम स्वीकार करने होंगे।",
    frameworks: "कम से कम एक फ्रेमवर्क चुनें।",
    gender: "कृपया एक लिंग चुनें।",
    time: "पसंदीदा समय चुनें।",
    bio: "जीवनी खाली नहीं हो सकती।",
    formBanner: "कृपया ऊपर दिए गए त्रुटियों को ठीक करें।",
    minlength: "न्यूनतम {min} अक्षर आवश्यक हैं।",
    invalidFormat: "इनपुट प्रारूप अमान्य है।"
  },
  dqi: {
    labels: {
      reportTitle: "नियामक डेटा गुणवत्ता सूचकांक रिपोर्ट उपभोक्ता",
      reportView: "रिपोर्ट दृश्य",
      consolidated: "संहित",
      portfolio: "पोर्टफोलियो",
      cycle: "संहित चक्र",
      portfolioLabel: "पोर्टफोलियो",
      fileName: "फ़ाइल नाम",
      getData: "डेटा प्राप्त करें",
      tableTitle: "डीक्यूआई रिपोर्ट तालिका",
      category: "श्रेणी",
      weight: "वजन",
      weightedPercentage: "भारित प्रतिशत",
      actualPercentage: "वास्तविक प्रतिशत",
      scoreLabel: "नियामक डेटा गुणवत्ता सूचकांक",
      segmentA: "जनसांख्यिकीय खंड सत्यापन (A)",
      segmentB: "व्यापार खंड सत्यापन (B)",
      fields: {
        name: "नाम",
        dob: "जन्मतिथि",
        pan: "पैन",
        voterId: "मतदाता पहचान पत्र",
        uid: "यूआईडी",
        pincode: "पिनकोड",
        phone: "फ़ोन",
        dpd: "डीपीडी / परिसंपत्ति वर्गीकरण",
        sanction: "उच्च क्रेडिट / स्वीकृत राशि",
        opened: "खाता खोलने की तिथि",
        balance: "शेष राशि",
        accountType: "खाता प्रकार (1- % अन्य)"
      },
      showSummary: "सारांश दिखाएं",
      hideSummary: "सारांश छुपाएं",
      summaryTitle: "डीक्यूआई रिपोर्ट सारांश"
    }
  },
  login: {
    title: 'लॉगिन',
    loginButton: 'लॉगिन',
    usernamePlaceholder: 'उपयोगकर्ता नाम',
    passwordPlaceholder: 'पासवर्ड',
    invalidCredentials: 'अमान्य उपयोगकर्ता नाम या पासवर्ड',
    required: 'यह फ़ील्ड आवश्यक है',
    welcomeMessage: 'वापसी पर स्वागत है!',
    logoutButton: 'लॉगआउट'
  }
}
