export default {
selfserviceportal : "Self Service Portal",
  home : "Home",
  settings : "Settings",
  language : "Language",
  theme : "Theme",
  switchTheme: "Switch Theme",
  switchToDark : "Switch to Dark Theme",
  switchToLight : "Switch to Light Theme"
}