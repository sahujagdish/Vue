export default {
  commercialdqi: {
    label: {
      title: 'Indice de Qualité des Données Réglementaires - Commercial',
      member: 'Membre',
      cycle: 'Cycle',
      totalBorrowers: 'Nombre total d’emprunteurs',
      totalCreditFacility: 'Facilité de crédit totale',
      fileName: 'Nom du fichier',
      portfolio: 'Portefeuille',
      submit: 'Soumettre',
      submitted: 'Soumis',
      exportOptions: 'Options d’exportation',
      exporting: 'Exportation...',
      notes: 'Notes',
      disclaimer: 'Avertissement',
      notesText: 'Longueur minimale pour l’adresse : 5 caractères ; valeurs incorrectes non autorisées...',
      disclaimerText: 'Toutes les informations sont basées sur les données fournies par le membre...',
      selectExportOption: 'Veuillez sélectionner une option d’exportation',
      dqi: 'Score DQI'
    },
    errors: {
      successMessage: 'terminé avec succès',
      exportFailed: 'Échec de l’exportation',
      exportSuccess: 'Exportation terminée avec succès'
    },
    tableHeaders: {
      category: 'Catégorie',
      weight: 'Poids',
      actual: 'Réel %',
      score: 'Score',
      invalid: 'Invalide'
    }
  },
  submit: 'Soumettre',
  labels: {
    name: "Nom",
    username: "Nom d’utilisateur",
    birthdate: "Date de naissance",
    favoriteFruit: "Fruit préféré",
    acceptTerms: "Accepter les conditions",
    frameworks: "Cadres",
    gender: "Sexe",
    preferredTime: "Heure préférée",
    bio: "Biographie",
    submit: "Soumettre",
    successMessage: "Formulaire soumis avec succès !"
  },
  errors: {
    required: "Ce champ est obligatoire.",
    username: {
      tooShort: "Le nom d’utilisateur doit comporter au moins {min} caractères.",
      tooLong: "Le nom d’utilisateur doit comporter au maximum {max} caractères.",
      invalid: "Format du nom d’utilisateur invalide."
    },
    birthdate: "La date de naissance est obligatoire.",
    fruit: "Veuillez sélectionner un fruit.",
    terms: "Vous devez accepter les conditions.",
    frameworks: "Sélectionnez au moins un cadre.",
    gender: "Veuillez sélectionner un sexe.",
    time: "Sélectionnez une heure préférée.",
    bio: "La biographie ne peut pas être vide.",
    formBanner: "Veuillez corriger les erreurs ci-dessus.",
    minlength: "Minimum {min} caractères requis.",
    invalidFormat: "Format d’entrée invalide."
  },
  dqi: {
    labels: {
      reportTitle: "Rapport Indice de Qualité des Données Réglementaires Consommateur",
      reportView: "Vue du rapport",
      consolidated: "Consolidé",
      portfolio: "Portefeuille",
      cycle: "Cycle consolidé",
      portfolioLabel: "Portefeuille",
      fileName: "Nom du fichier",
      getData: "Obtenir les données",
      tableTitle: "Tableau du rapport DQI",
      category: "Catégorie",
      weight: "Poids",
      weightedPercentage: "Pourcentage pondéré",
      actualPercentage: "Pourcentage réel",
      scoreLabel: "Indice de Qualité des Données Réglementaires",
      segmentA: "Validation du segment démographique (A)",
      segmentB: "Validations du segment commercial (B)",
      fields: {
        name: "Nom",
        dob: "Date de naissance",
        pan: "PAN",
        voterId: "Carte d’électeur",
        uid: "UID",
        pincode: "Code postal",
        phone: "Téléphone",
        dpd: "DPD / Classification des actifs",
        sanction: "Crédit élevé / Montant sanctionné",
        opened: "Date d’ouverture",
        balance: "Montant du solde",
        accountType: "Type de compte (1- % autres)"
      },
      showSummary: "Afficher le résumé",
      hideSummary: "Masquer le résumé",
      summaryTitle: "Résumé du rapport DQI"
    }
  },
  login: {
    title: 'Connexion',
    loginButton: 'Connexion',
    usernamePlaceholder: 'Nom d’utilisateur',
    passwordPlaceholder: 'Mot de passe',
    invalidCredentials: 'Nom d’utilisateur ou mot de passe invalide',
    required: 'Ce champ est obligatoire',
    welcomeMessage: 'Bon retour !',
    logoutButton: 'Déconnexion'
  }
}
