
// import sample from './sample.json'

// export default {
//   labels: {
//     ...sample.labels
//   },
//   errors: {
//     ...sample.errors
//   }
// }



export default {
  id: "fr-ID",
  name: "fr-Name",
  age: "fr-Age",
  gender: "fr-Gender",
  male: "fr-Male",
  female: "fr-Female",
  submit: "Submit",
  title: "fr-Title",
  body: "fr-Body",
  validation: {
    required: "This field is required",
    age: "Age must be a number"
  },
  selfserviceportal: "fr-Self Service Portal",
  home: "fr-Home",
  settings: "fr-Settings",
  language: "fr-Language",
  theme: "fr-Theme",
  switchTheme: "fr-Switch Theme",
  switchToDark: "fr-Switch to Dark Theme",
  switchToLight: "fr-Switch to Light Theme",
  posts: "Posts",
  labels: {
    name: "Nom",
    username: "Nom d'utilisateur",
    birthdate: "Date de naissance",
    favoriteFruit: "Fruit préféré",
    acceptTerms: "Accepter les conditions",
    frameworks: "Cadres",
    gender: "Genre",
    preferredTime: "Heure préférée",
    bio: "Biographie",
    submit: "Soumettre",
    successMessage: "Formulaire soumis avec succès !"
  },
  errors: {
    required: "Ce champ est requis.",
    username: {
      tooShort: "Le nom d'utilisateur doit contenir au moins {min} caractères.",
      tooLong: "Le nom d'utilisateur doit contenir au maximum {max} caractères.",
      invalid: "Le format du nom d'utilisateur est invalide."
    },
    birthdate: "La date de naissance est requise.",
    fruit: "Veuillez sélectionner un fruit.",
    terms: "Vous devez accepter les conditions.",
    frameworks: "Sélectionnez au moins un cadre.",
    gender: "Veuillez sélectionner un genre.",
    time: "Sélectionnez une heure préférée.",
    bio: "La biographie ne peut pas être vide.",
    formBanner: "Veuillez corriger les erreurs ci-dessus.",
    minlength: "Au moins {min} caractères requis.",
    invalidFormat: "Le format de saisie est invalide."
  },
  dqi: {
    labels: {
      reportTitle: "Rapport sur l'indice de qualité des données réglementaires - Consommateur",
      reportView: "Vue du rapport",
      consolidated: "Consolidé",
      portfolio: "Portefeuille",
      cycle: "Cycle consolidé",
      portfolioLabel: "Portefeuille",
      fileName: "Nom du fichier",
      getData: "Obtenir les données",
      tableTitle: "Tableau du rapport DQI",
      category: "Catégorie",
      weight: "Poids",
      weightedPercentage: "Pourcentage pondéré",
      actualPercentage: "Pourcentage réel",
      scoreLabel: "Indice de qualité des données réglementaires",
      segmentA: "Validation du segment démographique (A)",
      segmentB: "Validations du segment commercial (B)",
      fields: {
        name: "Nom",
        dob: "Date de naissance",
        pan: "PAN",
        voterId: "Carte d'électeur",
        uid: "UID",
        pincode: "Code postal",
        phone: "Téléphone",
        dpd: "DPD / Classification des actifs",
        sanction: "Montant élevé / Montant sanctionné",
        opened: "Date d'ouverture",
        balance: "Montant du solde",
        accountType: "Type de compte (1 - % autres)"
      },
      showSummary: "Afficher le résumé",
      hideSummary: "Masquer le résumé",
      summaryTitle: "Résumé du rapport DQI"
    }
  },
  login: {
    title: 'Connexion',
    loginButton: 'Se connecter',
    usernamePlaceholder: "Nom d'utilisateur",
    passwordPlaceholder: 'Mot de passe',
    invalidCredentials: "Nom d'utilisateur ou mot de passe incorrect",
    required: 'Ce champ est requis',
    welcomeMessage: 'Bon retour !',
    logoutButton: 'Se déconnecter'
  }


}