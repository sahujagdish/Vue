export default {
  commercialdqi: {
    label: {
      title: 'Índice de Qualidade de Dados Regulamentares - Comercial',
      member: 'Membro',
      cycle: 'Ciclo',
      totalBorrowers: 'Total de Tomadores',
      totalCreditFacility: 'Total de Facilidades de Crédito',
      fileName: 'Nome do Arquivo',
      portfolio: 'Portfólio',
      submit: 'Enviar',
      submitted: 'Enviado',
      exportOptions: 'Opções de Exportação',
      exporting: 'Exportando...',
      notes: 'Notas',
      disclaimer: 'Aviso',
      notesText: 'Comprimento mínimo para endereço: 5 caracteres; valores inválidos não permitidos...',
      disclaimerText: 'Todas as informações são baseadas nos dados fornecidos pelo membro...',
      selectExportOption: 'Por favor, selecione uma opção de exportação',
      dqi: 'Pontuação DQI'
    },
    errors: {
      successMessage: 'concluído com sucesso',
      exportFailed: 'Falha na exportação',
      exportSuccess: 'Exportação concluída com sucesso'
    },
    tableHeaders: {
      category: 'Categoria',
      weight: 'Peso',
      actual: '% Real',
      score: 'Pontuação',
      invalid: 'Inválido'
    }
  },
  submit: 'Enviar',
  labels: {
    name: "Nome",
    username: "Nome de usuário",
    birthdate: "Data de nascimento",
    favoriteFruit: "Fruta favorita",
    acceptTerms: "Aceitar termos",
    frameworks: "Frameworks",
    gender: "Gênero",
    preferredTime: "Horário preferido",
    bio: "Biografia",
    submit: "Enviar",
    successMessage: "Formulário enviado com sucesso!"
  },
  errors: {
    required: "Este campo é obrigatório.",
    username: {
      tooShort: "O nome de usuário deve ter pelo menos {min} caracteres.",
      tooLong: "O nome de usuário deve ter no máximo {max} caracteres.",
      invalid: "Formato de nome de usuário inválido."
    },
    birthdate: "A data de nascimento é obrigatória.",
    fruit: "Por favor, selecione uma fruta.",
    terms: "Você deve aceitar os termos.",
    frameworks: "Selecione pelo menos um framework.",
    gender: "Por favor, selecione um gênero.",
    time: "Selecione um horário preferido.",
    bio: "A biografia não pode estar vazia.",
    formBanner: "Por favor, corrija os erros acima.",
    minlength: "Mínimo de {min} caracteres obrigatórios.",
    invalidFormat: "Formato de entrada inválido."
  },
  dqi: {
    labels: {
      reportTitle: "Relatório Índice de Qualidade de Dados Regulamentares - Consumidor",
      reportView: "Visualização do Relatório",
      consolidated: "Consolidado",
      portfolio: "Portfólio",
      cycle: "Ciclo Consolidado",
      portfolioLabel: "Portfólio",
      fileName: "Nome do Arquivo",
      getData: "Obter Dados",
      tableTitle: "Tabela do Relatório DQI",
      category: "Categoria",
      weight: "Peso",
      weightedPercentage: "Percentual Ponderado",
      actualPercentage: "Percentual Real",
      scoreLabel: "Índice de Qualidade de Dados Regulamentares",
      segmentA: "Validação do Segmento Demográfico (A)",
      segmentB: "Validações do Segmento Comercial (B)",
      fields: {
        name: "Nome",
        dob: "Data de nascimento",
        pan: "PAN",
        voterId: "Título de Eleitor",
        uid: "UID",
        pincode: "Código Postal",
        phone: "Telefone",
        dpd: "DPD / Classificação de Ativos",
        sanction: "Crédito Alto / Valor Sancionado",
        opened: "Data de Abertura",
        balance: "Valor do Saldo",
        accountType: "Tipo de Conta (1- % outros)"
      },
      showSummary: "Mostrar Resumo",
      hideSummary: "Ocultar Resumo",
      summaryTitle: "Resumo do Relatório DQI"
    }
  },
  login: {
    title: 'Login',
    loginButton: 'Login',
    usernamePlaceholder: 'Nome de usuário',
    passwordPlaceholder: 'Senha',
    invalidCredentials: 'Nome de usuário ou senha inválidos',
    required: 'Este campo é obrigatório',
    welcomeMessage: 'Bem-vindo de volta!',
    logoutButton: 'Sair'
  }
}
