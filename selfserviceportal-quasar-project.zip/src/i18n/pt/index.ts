
// import sample from './sample.json'

// export default {
//     labels: {
//     ...sample.labels  
//   },
//   errors: {
//     ...sample.errors
//   }
// }


export default {
  id: "hi-ID",
  name: "hi-Name",
  age: "hi-Age",
  gender: "hi-Gender",
  male: "hi-Male",
  female: "hi-Female",
  submit: "Submit",
  title: "hi-Title",
  body: "hi-Body",
  validation: {
    required: "This field is required",
    age: "Age must be a number"
  },
  selfserviceportal: "Self Service Portal",
  home: "Home",
  settings: "Settings",
  language: "Language",
  theme: "Theme",
  switchTheme: "Switch Theme",
  switchToDark: "Switch to Dark Theme",
  switchToLight: "Switch to Light Theme",
  posts: "Posts",
  labels: {
    name: "नाम",
    username: "उपयोगकर्ता नाम",
    birthdate: "जन्म तिथि",
    favoriteFruit: "पसंदीदा फल",
    acceptTerms: "नियमों को स्वीकार करें",
    frameworks: "फ्रेमवर्क",
    gender: "लिंग",
    preferredTime: "पसंदीदा समय",
    bio: "जीवनी",
    submit: "जमा करें",
    successMessage: "फॉर्म सफलतापूर्वक सबमिट किया गया!"
  },
  errors: {
    required: "यह फ़ील्ड आवश्यक है।",
    username: {
      tooShort: "उपयोगकर्ता नाम कम से कम {min} अक्षरों का होना चाहिए।",
      tooLong: "उपयोगकर्ता नाम अधिकतम {max} अक्षरों का हो सकता है।",
      invalid: "उपयोगकर्ता नाम का प्रारूप अमान्य है।"
    },
    birthdate: "जन्म तिथि आवश्यक है।",
    fruit: "कृपया एक फल चुनें।",
    terms: "आपको नियमों को स्वीकार करना होगा।",
    frameworks: "कम से कम एक फ्रेमवर्क चुनें।",
    gender: "कृपया एक लिंग चुनें।",
    time: "कृपया एक पसंदीदा समय चुनें।",
    bio: "जीवनी खाली नहीं हो सकती।",
    formBanner: "कृपया ऊपर दी गई त्रुटियों को ठीक करें।"
  },
  dqi: {
    labels: {
      reportTitle: "Relatório do Índice de Qualidade de Dados Regulatórios - Consumidor",
      reportView: "Visualização do relatório",
      consolidated: "Consolidado",
      portfolio: "Portfólio",
      cycle: "Ciclo consolidado",
      portfolioLabel: "Portfólio",
      fileName: "Nome do arquivo",
      getData: "Obter dados",
      tableTitle: "Tabela do relatório DQI",
      category: "Categoria",
      weight: "Pesos",
      weightedPercentage: "Percentual ponderado",
      actualPercentage: "Percentual real",
      scoreLabel: "Índice de Qualidade de Dados Regulatórios",
      segmentA: "Validação do Segmento Demográfico (A)",
      segmentB: "Validações do Segmento Comercial (B)",
      fields: {
        name: "Nome",
        dob: "Data de nascimento",
        pan: "PAN",
        voterId: "Título de eleitor",
        uid: "UID",
        pincode: "Código postal",
        phone: "Telefone",
        dpd: "DPD / Classificação de ativos",
        sanction: "Crédito alto / Valor sancionado",
        opened: "Data de abertura",
        balance: "Valor do saldo",
        accountType: "Tipo de conta (1 - % outros)"
      },
      "showSummary": "Mostrar resumo",
      "hideSummary": "Ocultar resumo",
      "summaryTitle": "Resumo do relatório DQI"
    }
  }
}