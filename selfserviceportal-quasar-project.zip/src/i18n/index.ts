// import enUS from './en-US';

// export default {
//   'en-US': enUS,
// };



import en from './en'
import hi from './hi'
import pt from './pt'
import fr from './fr'

export default {
  en, hi, pt, fr
}



// import sample_en from './en/sample'

// import sample_fr from './fr/sample'

// import sample_hi from './hi/sample'

// export default {
//   en: {
//     ...sample_en,
//   },
//   fr: {
//     ...sample_fr,
//   },
//   hi: {
//     ...sample_hi,
//   }
// }
