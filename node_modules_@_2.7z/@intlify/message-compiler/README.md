# @intlify/message-compiler

The message compiler for intlify project

## :copyright: License

[MIT](http://opensource.org/licenses/MIT)
