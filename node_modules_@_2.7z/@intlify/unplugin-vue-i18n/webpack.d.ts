export { default } from './lib/webpack'
