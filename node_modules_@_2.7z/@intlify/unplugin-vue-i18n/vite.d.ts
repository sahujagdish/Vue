export { default } from './lib/vite'
