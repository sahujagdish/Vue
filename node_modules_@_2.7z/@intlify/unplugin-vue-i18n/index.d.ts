export { default, unplugin, PluginOptions, SFCLangFormat } from './lib/index'
