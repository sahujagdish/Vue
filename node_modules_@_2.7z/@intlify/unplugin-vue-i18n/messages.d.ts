declare module '@intlify/unplugin-vue-i18n/messages' {
  import type { I18nOptions } from 'vue-i18n'

  const messages: I18nOptions['messages']
  export default messages
}
