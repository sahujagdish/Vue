export { PluginOptions, SFCLangFormat } from './lib/types'
